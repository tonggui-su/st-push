import os
import setuptools

with open("st_push/README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setuptools.setup(
    name="st-push",
    version="1.1",
    author="st-push contributors",
    author_email="",
    description="Streamlit real-time push via WebSocket route — encrypted, module-routed, multi-device",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="",
    packages=setuptools.find_packages(
        include=["st_push", "st_push.*", "st_push.comp.*"],
    ),
    include_package_data=True,
    python_requires=">=3.8",
    install_requires=[
        "streamlit >= 1.59.1",
        "starlette >= 0.40.0",
    ],
    classifiers=[
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Operating System :: OS Independent",
        "Framework :: Streamlit",
    ],
)
