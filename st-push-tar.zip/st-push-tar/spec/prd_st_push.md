# prd_st_push.md — 设计文档：WebSocket 路由 + 模块系统 + 加密

> st_push 是真推送通道：WebSocket 路由挂载到 Streamlit 的 Starlette App，
> 服务器通过专用 WS 连接主动推送消息到浏览器，零空闲流量，实时送达，每连接加密。

## 1. 问题背景

Streamlit 的 `/_stcore/stream` WebSocket 承载 protobuf `ForwardMsg` delta，与脚本 rerun 生命周期紧耦合，
用户代码无法按需推送。`ForwardMsg.parent_message` 只到达宿主页面，不转发到组件 iframe。

解决思路：在 Streamlit 的 Starlette App 上挂载独立 WebSocket 路由 `/st_push/ws`，
组件 iframe 直连该路由，建立专用推送通道，绕过 delta/rerun 循环。

## 2. 架构

```
                          ┌──────────────────────────────────┐
                          │        Streamlit Runtime         │
                          │                                  │
                          │  ┌────────────────────────────┐  │
                          │  │     Starlette App          │  │
                          │  │  ┌──────────────────────┐  │  │
                          │  │  │ /_stcore/stream      │  │  │  ← Streamlit 的 WS（protobuf delta）
                          │  │  │ /st_push/ws  ◄─────┼──┼──┼── st_push WS 路由（JSON 推送通道）
                          │  │  │ /st_push/log       │  │  │  ← 前端日志上报
                          │  │  │ /component/...        │  │  │
                          │  │  └──────────────────────┘  │  │
                          │  └────────────────────────────┘  │
                          │           ▲                       │
                          │    ┌──────┴──────┐                │
                          │    │   PushHub   │ (singleton)    │  ← 传输层
                          │    │ channel→conn│  ← register/unregister (1:1)
                          │    │ event loop  │  ← 跨线程调度引用
                          │    │ modules     │  ← uuid→ModuleHandle
                          │    └──────┬──────┘
                          │           │
                          │    ┌──────┴──────┐                │
                          │    │ChannelRegistry│ (singleton)   │  ← 业务层（可选）
                          │    │ user→[channel]│  ← bind/unbind (1:N)
                          │    │ send_to_user  │  ← 解析 user→channels
                          │    └──────┬──────┘
                          │           │
                          │    Streamlit Script Thread (sync)
                          │    PushClient.send_msg() → hub.enqueue_to_channel()
                          │    ChatClient.send() → registry.send_to_module()
                          │           │
                          └───────────┼──────────────────────────
                                      │
                           loop.call_soon_threadsafe()  ← 非阻塞
                                      │
                                      ▼
                             Server Event Loop
                             (Uvicorn/Starlette)
                                      │
                             sender_task: queue.get()
                                      │
                             encrypt(data) → WebSocket.send_text()
                                      │
                                      ▼
                              Browser (component iframe)
                              ws.onmessage → decrypt
                                           → dispatch to module callback
                                           → or setComponentValue (user-level)
```

### 架构分层

| 层 | 文件 | 职责 | 知道 user？ |
|---|------|------|------------|
| **传输层** | `hub.py` / `routes.py` / `__init__.py` | `channel→conn`(1:1) + module 路由 | 否 |
| **业务层**（可选） | `registry.py` | `user→[channel_id]`(1:N) 多端登录 | 是 |

**关键约束**：脱离 user-channel 关系，PUSH 也能正常运作。传输层 `PushClient(channel_id)` / `ModuleHandle.send_to_channel(to_channel)` 只认 channel。业务层是可选包装，业务组件（st_chat/st_notify）用它解析 `to_user→channels`。

### 关键组件

| 组件 | 文件 | 职责 |
|------|------|------|
| `PushHub` | `st_push/hub.py` | 传输层单例：channel→conn(1:1) 映射、per-conn 队列+sender task、模块注册 |
| `PushConnection` | `st_push/hub.py` | 单连接封装：channel_id + asyncio.Queue + sender task + 加密密钥 |
| `ModuleHandle` | `st_push/hub.py` | 模块句柄：send_to_channel() / broadcast() |
| `ChannelRegistry` | `st_push/registry.py` | 业务层单例：user→[channel_id](1:N)，send_to_user() / send_to_module() |
| `push_websocket_endpoint` | `st_push/routes.py` | `/st_push/ws` 路由 + 加密握手 |
| `create_push_routes()` | `st_push/routes.py` | 返回路由列表供 `App(routes=...)` |
| `log_endpoint` | `st_push/routes.py` | `POST /st_push/log` 前端日志上报 |
| `PushClient` | `st_push/__init__.py` | 传输层 API：`send_msg(to_channel)` / `connect()` |
| `register()` | `st_push/__init__.py` | 模块注册 SDK 入口 |
| `crypto` | `st_push/crypto.py` | AES-256-GCM + XOR/HMAC 回退 |
| 前端 | `st_push/frontend/build/index.html` | 内联协议 + WS 客户端 + 加解密 + 模块分发 |

## 3. 连接生命周期

1. **启动**：`App(routes=st_push.create_push_routes())` 挂载 WS 路由到同一 Uvicorn 服务器，无额外端口
2. **前端连接**：组件 iframe（`connect()` 渲染）打开 WS 到 `/st_push/ws`，发送 `{"channel": "ch-abc123"}`
3. **Hub 注册 + 密钥交换**：路由调用 `hub.set_loop()`，生成 32 字节密钥，注册连接（channel→conn 1:1），发送 ack（明文含密钥 + channel）
4. **启用加密**：ack 发送后 `encryption_enabled = True`，后续消息全部加密
5. **业务层绑定**（可选）：`ChannelRegistry.bind(user="alice", channel_id="ch-abc123")` 建立 user→channel 映射
6. **推送**：`registry.send_to_user("bob", msg)` → 解析 `bob→[channel_id]` → `hub.enqueue_to_channel(channel_id, msg)`（`call_soon_threadsafe` 非阻塞）→ sender task 加密 + 写 WS
7. **前端接收**：`ws.onmessage` → 解密 → 按 `targetModule` 分发到模块 callback 或 `setComponentValue`

## 4. 高性能队列架构

每个 `PushConnection` 拥有 `asyncio.Queue(maxsize=1000)` + 后台 sender task：

```
Script Thread (sync)                    Server Loop (async)
─────────────────────────               ──────────────────
PushClient.send_msg(to_channel="ch-x")
  → hub.enqueue_to_channel("ch-x", msg)
    → conn.enqueue(data, loop)
      → loop.call_soon_threadsafe(        │
          queue.put_nowait(data)           │
        )                                  │
      → returns True immediately           │
                                           ▼
                                    sender_task: await queue.get()
                                    → encrypt(data)
                                    → websocket.send_text(encrypted)
```

**关键区别**：`call_soon_threadsafe`（非阻塞，高吞吐）vs 旧方案 `run_coroutine_threadsafe + future.result()`（阻塞，低吞吐）

## 5. 模块注册系统

### 5.1 问题

单一推送通道不够。多个模块（聊天、通知、待办...）共存时，各自需要独立消息路由，互不干扰。

### 5.2 设计

```
Python (云侧)                           Frontend (浏览器侧)
─────────────────                       ──────────────────
module = st_push.register("chat")
  → Hub 分配 UUID
  → 返回 ModuleHandle(uuid, name)
                                        module UUID 通过组件参数传给前端
                                        window.parent.st_push.register(uuid, callback)
                                          → callback 注册表存 uuid→callback

module.send_msg(payload, to_user)
  → hub.enqueue_to_module(uuid, payload, to_user)
  → WS: {"type":"st_push", "targetModule": uuid, "msg": payload}
                                        ws.onmessage
                                          → decrypt
                                          → 按 targetModule 分发
                                          → 调用 callback(uuid, payload)
```

### 5.3 云侧 API

```python
import st_push

chat = st_push.register("chat")
# chat.uuid → "a1b2c3d4-..."
# chat.name → "chat"

# 传输层：按 channel 发送
chat.send_to_channel(payload={"text": "Hello"}, to_channel="ch-xyz789")
chat.broadcast(payload={"alert": "restart"})  # 广播给所有在线 channel

# 业务层（经 ChannelRegistry）：按 user 发送
from st_push.registry import ChannelRegistry
registry = ChannelRegistry.instance()
registry.send_to_module("bob", chat.uuid, {"text": "Hello"}, from_user="alice")
```

### 5.4 前端 API

```javascript
// 在其他组件 iframe 中：
const handle = window.parent.st_push.register(moduleUuid, (msg) => {
    console.log("Received:", msg);
});
handle.unregister();  // 卸载时注销
```

### 5.5 消息格式

```json
{
  "type": "st_push",
  "fromUser": "alice",
  "targetModule": "a1b2c3d4-...",
  "msg": {"text": "Hello"},
  "ts": 1234567890.123
}
```

- 有 `targetModule`：前端按 UUID 分发到对应 callback，**不调 setComponentValue**（避免 rerun）
- 无 `targetModule`：用户级消息，调 `setComponentValue`，`connect()` 返回值可读

### 5.6 Hub 不跟踪前端模块

Hub 只在消息中包含 `targetModule`，前端本地分发。Hub 不记录哪些前端模块已注册，保持无状态。

## 6. 每连接加密

### 6.1 握手流程

1. 客户端发送 `{"channel": "ch-abc123"}`（明文，唯一不加密的消息）
2. 服务端生成 32 字节随机密钥，ack 中返回 `sessionKey`（base64）+ `channel`
3. **ack 必须明文**——客户端还没拿到密钥
4. ack 发送后 `encryption_enabled = True`
5. 后续双向消息全部加密

### 6.2 算法

- 优先 AES-256-GCM（`cryptography` 库 / Web Crypto API `crypto.subtle`）
- 回退 XOR+HMAC-SHA256（stdlib / `crypto.subtle.digest`）

### 6.3 wire 格式

```json
{"v":1, "algo":"aes-gcm", "n":"<base64 nonce>", "c":"<base64 ct+tag>"}
```

XOR 回退模式额外包含 `"h":"<base64 hmac>"`。

### 6.4 易错点

- 错误：先设 `encryption_enabled = True` 再发 ack → ack 被加密，客户端无法解密
- 正确：先发明文 ack（含密钥），**再**设 `encryption_enabled = True`

## 7. 消息协议

### Client → Server

| 消息 | 用途 |
|------|------|
| `{"channel": "ch-abc123"}` | 注册身份（明文，加密前） |
| `{"v":1,"algo":"aes-gcm","n":"...","c":"..."}` | 加密消息（注册后） |

解密后的客户端消息：
| 消息 | 用途 |
|------|------|
| `{"msg": "hello", "toChannel": "ch-xyz789"}` | 发消息给其他 channel |
| `{"msg": {...}, "toChannel": "ch-xyz789", "targetModule": "uuid"}` | 模块消息 |

### Server → Client

| 消息 | 用途 |
|------|------|
| `{"type":"st_push_ack","channel":"ch-abc123","sessionKey":"...","algo":"...","ts":...}` | 注册 ACK + 密钥交换（明文） |
| `{"v":1,"algo":"aes-gcm","n":"...","c":"..."}` | 加密推送（注册后） |
| `{"type":"st_push_error","msg":"not registered"}` | 错误（明文，注册前） |

解密后的服务端推送：
```json
{
  "type": "st_push",
  "fromUser": "alice",
  "targetModule": "a1b2c3d4-...",
  "msg": {"text": "Hello"},
  "ts": 1234567890.123
}
```

## 8. API

### 传输层 — `PushClient(channel_id)`

| 参数 | 类型 | 说明 |
|------|------|------|
| `channel_id` | `str` | 传输层 channel ID，1:1 映射到 WS 连接 |

#### `send_msg(msg, to_channel=None) -> bool`

| 参数 | 类型 | 说明 |
|------|------|------|
| `msg` | `Any` | 消息内容 |
| `to_channel` | `str \| None` | 目标 channel，None 发给自己 |

返回 `True` 已入队，`False` channel 离线。

#### `connect() -> dict | None`

渲染不可见 WS 传输组件。用户级消息返回最新消息，模块消息返回值忽略。

### 传输层 — `register(name: str) -> ModuleHandle`

注册模块，返回带 UUID 的句柄。

#### `ModuleHandle.send_to_channel(payload, to_channel, from_user="SYSTEM") -> bool`

发送模块消息到指定 channel（fire-and-forget）。

#### `ModuleHandle.broadcast(payload, from_user="SYSTEM") -> bool`

广播给所有在线 channel。

### 业务层 — `ChannelRegistry.instance() -> ChannelRegistry`

业务层单例，`user→[channel_id]`(1:N) 映射。

#### `bind(user, channel_id)`

绑定 user→channel（多端友好，1:N）。channel 切换 user 时自动从旧 user 移除。

#### `send_to_user(user, msg, from_user="SYSTEM", module_uuid=None, exclude_channel=None) -> bool`

发送消息给 user 的所有 channel。`exclude_channel` 排除指定 channel（用于多端发送同步）。

#### `send_to_module(user, module_uuid, payload, from_user="SYSTEM", exclude_channel=None) -> bool`

发送模块消息给 user 的所有 channel。

#### `broadcast(msg, from_user="SYSTEM", module_uuid=None) -> bool`

广播给所有在线 channel。

## 9. 设计决策

### 为什么用独立 WS 而不是 ForwardMsg？

`ForwardMsg.parent_message` 只到达宿主页面，不转发到组件 iframe。独立 WS 给 iframe 自己的实时通道。

### 为什么挂载到 Streamlit 的 Starlette App？

- 单端口：无 CORS、无反向代理
- 共享中间件：CORS、XSRF、auth
- 共享生命周期：WS 随 Streamlit 启停

### 为什么传输层与业务层解耦？

传输层（hub.py）只管 `channel→conn`(1:1) + module 路由，不知 user 为何物。业务层（registry.py）管 `user→[channel_id]`(1:N)。

- **职责清晰**：传输层只认 channel，业务层解析 user→channels
- **可独立运作**：脱离 user-channel 关系，PUSH 也能正常运作（直接 `PushClient.send_msg(to_channel=...)`）
- **多端登录**：一个 user 可有多个 channel（多标签/多设备），业务层统一管理
- **业务层可选**：registry 是包装层，不需要 user 概念的场景可以不用

### 为什么用 `st.query_params` 持久化 user 身份？

`session_id` 每次刷新变化。`st.query_params["st_push_user"]` 在 URL 中稳定，刷新后恢复。channel_id 在 `session_state` 中生成，刷新后变化（新连接），但 user 身份通过 query_params 恢复，registry 重新绑定 user→新 channel。

### 为什么多端发送同步要 echo 给发送者？

场景：alice 在桌面端发消息给 bob，alice 的手机端也应看到发出的消息。

`ChatClient.send()` 做两件事：
1. 投递给接收者的所有 channel（接收同步）
2. echo 给发送者的其他 channel，排除发起方 channel（发送同步）

排除发起方 channel 是因为它的本地 UI 已经有该消息（前端 `sendMessage()` 时已 `appendMessage`），重复投递会导致重复显示。registry 提供 `exclude_channel` 原语支持这一模式。

### 为什么用 per-connection 队列？

- `call_soon_threadsafe` 立即返回（非阻塞）
- sender task 按自身节奏 drain 队列
- 无 `future.result()` 阻塞，高吞吐
- 队列满则丢消息（优雅背压）

### 为什么 per-connection 加密而不是 per-user？

- 每连接独立密钥，重连生成新密钥（前向保密 lite）
- 不跨标签页/设备共享密钥

### 为什么懒加载 `declare_component`？

模块级调用可能无 `ScriptRunContext`，延迟到首次调用确保在脚本执行上下文中。

## 10. 使用示例

### 启动器

```python
# app.py
import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from streamlit.web.server.starlette import App
import st_push

app = App("my_script.py", routes=st_push.create_push_routes())

if __name__ == "__main__":
    app.run()
```

### 脚本

```python
# my_script.py
from st_push import PushClient, generate_channel_id
from st_push.registry import ChannelRegistry

# 传输层
channel_id = generate_channel_id()
client = PushClient(channel_id)
client.connect()  # 渲染不可见 WS 传输

# 业务层（可选）：绑定 user→channel
registry = ChannelRegistry.instance()
registry.bind(user="alice", channel_id=channel_id)

# 发送给其他 user（经 registry 解析）
registry.send_to_user("bob", "Hello Bob!", from_user="alice")
```

### 运行

```bash
python app.py
```

## 11. 文件结构

```
st_push/
  __init__.py                    PushClient(channel_id) API + register() + 导出 ChannelRegistry
  hub.py                         传输层 PushHub — channel→conn(1:1) + per-conn 队列 + sender task + 模块注册
  registry.py                    业务层 ChannelRegistry — user→[channel_id](1:N) + send_to_user/send_to_module
  routes.py                      WebSocket 路由 + 加密握手 + 日志端点
  crypto.py                      AES-256-GCM + XOR/HMAC 回退
  frontend/build/index.html      内联协议 + WS 客户端 + 加解密 + 模块分发

st_chat/
  __init__.py                    ChatClient(user_name, channel_id) — send() 含多端发送同步
  frontend/build/index.html      聊天窗口 UI

st_notify/
  __init__.py                    NotificationClient — send_notification() 经 registry 解析
  frontend/build/index.html      铃铛图标 + 弹窗 UI

demos/
  chat_app.py                    聊天启动器
  chat_script.py                聊天脚本（session_state 生成 channel_id，ensure_registry_binding）
  notification_app.py            通知启动器
  notification_script.py         通知脚本
```

## 12. Streamlit 源码引用

| 特性 | 位置 |
|------|------|
| `App` 类（路由挂载） | `starlette_app.py:278` |
| `create_streamlit_routes` | `starlette_app.py:131` |
| 组件路由 | `starlette_routes.py:786` |
| `declare_component` | `component_registry.py:53` |
| `CustomComponent.__call__` | `custom_component.py:47` |
| `get_script_run_ctx` | `script_run_context.py:423` |
| `ScriptRunContext.session_id` | `script_run_context.py:197` |
| `server.disconnectedSessionTTL` | `config.py:1134` |
