# st_push 接入指南

> 基于 v3.0 架构。设计文档见 `spec/prd_st_push_2.md`，API 文档见 `st_push/README.md`。

## 核心概念

| 概念 | 说明 |
|------|------|
| **channel** | 传输层身份，1:1 映射一条 WebSocket 连接 |
| **user** | 业务层身份，1:N 映射多个 channel（多端登录） |
| **module** | 组件身份，按 name 注册（幂等），前端按 moduleId 分发消息 |
| **PushClient** | session 单例，公共基础设施，由应用层创建注入组件 |

## 接入步骤

### 1. 启动器：挂载 WebSocket 路由

```python
# app.py
from streamlit.web.server.starlette import App
import st_push

app = App("script.py", routes=st_push.create_push_routes())
if __name__ == "__main__":
    app.run()
```

### 2. 脚本：创建 PushClient + 使用组件

```python
import streamlit as st
from st_push import PushClient
from st_push.comp.chat import ChatClient
from st_push.comp.notify import NotificationClient

# 应用层创建公共 PushClient（session 单例，一个会话一个 WS 连接）
push_client = PushClient.session_instance(user="alice")

# 注入给组件（共享同一个 push_client）
chat = ChatClient(push_client, user_name="alice")
notifier = NotificationClient(push_client, user_name="alice")

# 渲染
chat.render(peer="bob")
notifier.render()

# 发送
chat.send("Hello!", to_user="bob")
notifier.send_notification(to_user="bob", title="新任务", body="修复登录Bug")
notifier.broadcast_alert(title="系统维护", body="10分钟后重启")
```

### 3. 仅用推送通道（不用 UI 组件）

```python
from st_push import PushClient

push_client = PushClient.session_instance(user="alice")
module = push_client.register_module("my_module")

# 发送给指定用户（经 UserChannelManage 解析 user→channels）
module.send_msg({"text": "hello"}, target_user="bob")

# 广播给所有在线 channel
module.broadcast_msg({"alert": "restart"})

# 查询在线状态
push_client.is_online("bob")
```

## 自定义组件接入

如需开发自己的实时 UI 组件，前端需实现三要素：

| 要素 | 代码 | 作用 |
|------|------|------|
| callback 注册 | `window.parent.st_push.register(moduleId, fn)` | 接收 module 推送消息，直接操作 DOM |
| UI 渲染 | `renderUI()` | 在 iframe 内渲染组件 UI |
| 出站回传 | `window.Streamlit.setComponentValue({...})` | 用户操作时通知 Python，触发 rerun |

> **关键**：callback 内**不要**调用 `setComponentValue`，否则每条推送都触发 rerun。仅在用户主动操作时才回传。

前端模板参考 `st_push/comp/chat/frontend/build/index.html`。

## 多端同步

```
alice(channel_A) 发消息给 bob
  ├─ → bob 的所有 channel（接收同步）
  └─ → alice 的所有 channel（含发起方）（发送同步）
       前端按 fromUser+toUser+content+ts 去重
```

`module.send_msg(payload, target_user=to_user)` 投递给接收者；`module.send_msg(payload)`（target_user=None）echo 给发送者所有 channel。不排除发起方，前端去重。

## 运行演示

```bash
python demos/chat_app.py          # 聊天
python demos/notification_app.py  # 通知
```
