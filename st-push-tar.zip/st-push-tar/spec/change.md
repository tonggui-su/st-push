# change.md — st-push 踩坑记录 + 版本变更日志

> 本文件合并了历史踩坑记录（原 AGENTS.md）和版本变更日志（原 CHANGELOG.md）。
> 每次修改后追加变更记录；遇到新坑也记录于此。

> **版本规则**：change.md 内部版本号从 v1 开始迭代，每次加一（v1, v2, v3...）。
> 发布版本号（setup.py / PyPI）由工程师指定，独立于 change.md 内部版本号。
> 0.1 为历史发布版本（旧版 Tornado + 方案 A），v1 起为 v3.0 架构重构后的新迭代。

---

## 踩坑记录

### 1. ParentMessage 字段名：`message` 不是 `content`

**现象**：`AttributeError: 'ParentMessage' object has no attribute 'content'`

**原因**：Streamlit 的 `ParentMessage` proto 字段是 `message`，不是 `content`。

**修复**：使用 `msg.message` 而非 `msg.content`。

**源码位置**：`streamlit/proto/ParentMessage.proto`

---

### 2. App() 脚本路径必须用绝对路径

**现象**：`FileNotFoundError: Streamlit script not found: 'D:\Learn\streamlit-push\demos\****'`

**原因**：`App("demos/chat_script.py")` 的相对路径解析基于 cwd，启动时 cwd 不固定导致找不到文件。

**修复**：用 `os.path.join(os.path.dirname(os.path.abspath(__file__)), "chat_script.py")` 构造绝对路径。

---

### 3. 前端组件必须内联实现 Streamlit 协议

**现象**：`having trouble loading the st_push.st_push component`

**原因**：`declare_component` 需要前端 `index.html` 实现 Streamlit 组件协议（`setComponentReady` / `setComponentValue` / `setFrameHeight` + `postMessage` 监听），不能只写业务逻辑。

**修复**：在 `frontend/build/index.html` 中手写完整的 Streamlit 组件协议：

```javascript
window.Streamlit = {
  setComponentReady: () => window.parent.postMessage({isStreamlitMessage: true, type: "streamlit:componentReady", apiVersion: 1}, "*"),
  setComponentValue: (v) => window.parent.postMessage({isStreamlitMessage: true, type: "streamlit:setComponentValue", value: v, dataType: "json"}, "*"),
  setFrameHeight: (h) => window.parent.postMessage({isStreamlitMessage: true, type: "streamlit:setFrameHeight", height: h}, "*"),
  events: new EventTarget()
};
window.addEventListener("message", (e) => { if (e.data?.type === "streamlit:render") ... });
```

---

### 4. 方案 A 不能用 ForwardMsg 推送——fragment 队列轮询替代

**现象**：方案 A 只在当前 session 有通知，其他 session 收不到。

**原因**：`ForwardMsg.parent_message` 只发到宿主环境（浏览器主页面），**不会转发到组件 iframe**。组件 iframe 无法收到 ForwardMsg 推送。

**修复**：改用 `st.fragment(run_every=1)` 每秒检查 hub 内存队列：

```python
@st.fragment(run_every=1)
def _poll_messages():
    msgs = hub.pop_messages(user_name)
    if msgs:
        st.session_state[key].extend(msgs)
        st.rerun()
```

**关键 API**：`st.fragment(run_every=1)` — `streamlit/runtime/fragment.py:628`

---

### 5. 方案 B 不能从 Streamlit 脚本线程直接调用 async 方法

**现象**：`send_msg()` 调用 hub 的 async `send_to_user()` 时报错或死锁。

**原因**：Streamlit 脚本在独立线程执行，不在 asyncio 事件循环中。直接 `asyncio.run()` 会创建新循环，无法访问 Uvicorn 服务器循环中的 WebSocket 连接。

**初始修复（已废弃 — 低性能）**：
1. Hub 存储 Uvicorn 事件循环引用：`hub.set_loop(asyncio.get_running_loop())`
2. 用 `asyncio.run_coroutine_threadsafe()` + `future.result(timeout=5.0)` 阻塞等待

**最终修复（高性能队列架构）**：
1. Hub 存储 Uvicorn 事件循环引用：`hub.set_loop(asyncio.get_running_loop())`（在 WebSocket 路由中设置）
2. 每个 `PushConnection` 拥有独立的 `asyncio.Queue(maxsize=1000)` + 后台 sender task
3. 发送方用 `loop.call_soon_threadsafe()` 将消息放入队列（**非阻塞**，fire-and-forget）
4. sender task 在服务器循环中 drain 队列，写 WebSocket：

```python
def enqueue(self, data: dict, loop) -> bool:
    def _do_enqueue():
        try:
            self._send_queue.put_nowait(data)
        except asyncio.QueueFull:
            ...  # drop
    loop.call_soon_threadsafe(_do_enqueue)
    return True

async def _sender_loop(self):
    while True:
        data = await self._send_queue.get()
        if data is None: break  # shutdown sentinel
        await self.websocket.send_text(...)
```

5. `PushClient.send_msg()` 调用 `hub.enqueue_from_user()` 而非阻塞 sync 版本
6. 路由端用 `send_*_direct()` (async) 直接发送，不经队列

**关键区别**：`call_soon_threadsafe` vs `run_coroutine_threadsafe`
- `run_coroutine_threadsafe` + `future.result()` = 阻塞等待，低吞吐
- `call_soon_threadsafe` = 立即返回，高吞吐，fire-and-forget

---

### 6. `recv_msg()` 已废弃——改为 `connect()` + 模块注册系统

**现象**：原 `recv_msg()` 通过 `setComponentValue` 触发 rerun 来传递消息，但模块消息不需要回到 Python 端。

**修复**：
- `recv_msg()` → `connect()`：仅渲染不可见 WS 传输组件，不依赖返回值
- 模块消息：前端 callback 直接处理，**不调用 `setComponentValue`**（避免无谓 rerun）
- 用户级消息（无 targetModule）：仍调 `setComponentValue`，`connect()` 返回值可读
- 离线缓冲已移除：PUSH = 仅在线推送，离线返回 False，端侧 GET 获取历史

---

### 7. `declare_component` 必须懒加载

**现象**：模块级调用 `components.declare_component()` 可能因无 ScriptRunContext 报错。

**修复**：用 `_get_component_func()` 懒初始化模式：

```python
_component_func = None
def _get_component_func():
    global _component_func
    if _component_func is None:
        _component_func = components.declare_component("st_push", path=build_dir)
    return _component_func
```

---

### 8. 跨刷新用户身份：用 `st.query_params` 持久化

**现象**：浏览器刷新后 Streamlit 分配新 `session_id`，hub 中 `user→session_id` 映射失效。

**修复**：用户身份写入 `st.query_params`（URL 持久化）：

```python
st.query_params["st_push_user"] = user_name  # 写入 URL
user = st.query_params.get("st_push_user")    # 刷新后恢复
```

- 方案 A：hub 队列按 `user_name` 索引，与 `session_id` 无关
- 方案 B：前端 WebSocket 重连后自动注册 `user_name`

---

### 9. 每连接加密：AES-256-GCM 握手 + 前后端加解密

**现象**：WebSocket 传输明文，存在安全隐患。

**修复**：每个 WS 连接在注册时协商独立密钥：

1. 客户端发送 `{"user": "alice"}`（明文，仅此一条）
2. 服务端生成 32 字节随机密钥，在 ack 中返回 `sessionKey`（base64）
3. **ack 必须明文发送**——客户端还没拿到密钥，不能加密
4. ack 发送完毕后，`conn.encryption_enabled = True`
5. 后续双向消息全部加密（AES-256-GCM 或 XOR+HMAC fallback）

**关键文件**：
- `st_push/crypto.py`：Python 端加解密
- `st_push/frontend/build/index.html`：JS 端加解密（Web Crypto API）

**加密算法选择**：
- 优先 AES-256-GCM（`cryptography` 库 / Web Crypto API `crypto.subtle`）
- 回退 XOR+HMAC-SHA256（stdlib / Web Crypto API `crypto.subtle.digest`）

**wire 格式**：`{"v":1, "algo":"aes-gcm", "n":"<base64 nonce>", "c":"<base64 ct+tag>"}`

**易错点**：ack 发送时机
- 错误：先设 `encryption_enabled = True`，再发 ack → ack 被加密，客户端无法解密
- 正确：先发明文 ack（含密钥），**再**设 `encryption_enabled = True`

---

## 关键 Streamlit 源码位置

| 内容 | 位置 |
|------|------|
| `st.fragment(run_every=)` 定义 | `lib/streamlit/runtime/fragment.py:628` |
| `server.disconnectedSessionTTL` 配置 | `lib/streamlit/config.py:1134-1148` |
| 组件路由 `/component/{path:path}` | `lib/streamlit/web/server/starlette/starlette_routes.py:786-820` |
| `ScriptRunContext.session_id` / `user_info` | `lib/streamlit/runtime/scriptrunner_utils/script_run_context.py:197,203` |
| `ParentMessage.message` 字段 | `streamlit/proto/ParentMessage.proto` |
| `Runtime.instance().get_client()` | Runtime 单例 API |
| `App` 类（路由挂载） | `lib/streamlit/web/server/starlette/starlette_app.py:278` |
| `create_streamlit_routes` | `lib/streamlit/web/server/starlette/starlette_app.py:131` |
| `declare_component` | `lib/streamlit/components/v1/component_registry.py:53` |
| `CustomComponent.__call__` | `lib/streamlit/components/v1/custom_component.py:47` |
| `get_script_run_ctx` | `lib/streamlit/runtime/scriptrunner_utils/script_run_context.py:423` |

---

## 版本变更日志

### v2.1.0 — 2025-07-13 — 心跳机制 + 失效 channel 自动清理

#### Added
- **心跳机制**：每 60s 向所有在线 channel 发 `st_push_ping`，客户端回复 `st_push_pong`；超过 120s 无 pong 的 channel 标记为失效并移除
- `PushConnection.last_pong` 字段 + `update_pong()` / `is_heartbeat_stale()` 方法
- `PushHub._heartbeat_loop()` 后台任务：自动清理失效连接，同时清理 registry 中的 user→channel 绑定
- 前端 `_sendPong()`：收到 ping 后回复加密 pong
- `ChannelRegistry` 懒清理：`send_to_user()` / `is_online()` 发送时检查 channel 是否在 hub 中仍在线，不在线的自动 unbind

#### Changed
- `PushHub.set_loop()` 首次设置 loop 时自动启动心跳任务
- `routes.py` WS 端点新增 `st_push_pong` 消息处理分支
- `registry.is_online()` 不再只看 registry 映射，还要检查 hub 中 channel 是否在线

### v2.0.1 — 2025-07-13 — 多端发送同步

#### Added
- `ChannelRegistry.send_to_user()` / `send_to_module()` 新增 `exclude_channel` 参数：排除指定 channel（用于发送方 echo 时避免重复显示）
- `ChatClient.send()` 多端发送同步：投递给接收者后，echo 给发送者的其他 channels（排除发起方 channel），确保多端登录时发送的消息在各端同步显示

### v2.0.0 — 2025-07-13 — 架构分层：传输层与业务层解耦

#### 架构变更
- **传输层（st_push 核心）完全移除 user 概念**：`hub.py` 只维护 `channel_id → PushConnection`（1:1），消息路由按 channel + module UUID，不知 user 为何物
- **新增业务层 `st_push/registry.py`**：`ChannelRegistry` 单例，维护 `user → [channel_id]`（1:N 多端登录），对外暴露 `send_to_user()` / `send_to_module()` / `broadcast()` 等业务方法
- **关键约束**：脱离 user-channel 关系，PUSH 也能正常运作。传输层 `PushClient(channel_id)` / `ModuleHandle.send_to_channel()` 只认 channel

#### Changed
- `st_push/hub.py` — `PushConnection.channel_id` 替代 `user_name`；`_connections: dict[str, PushConnection]`（1:1）；所有 enqueue/send 方法改用 `target_channel` 参数
- `st_push/__init__.py` — `PushClient(channel_id)`，`send_msg(msg, to_channel=None)`；导出 `ChannelRegistry` / `generate_channel_id`
- `st_push/routes.py` — WS 注册消息 `{user:}` → `{channel:}`；ack 含 `channel` 字段
- `st_push/frontend/build/index.html` — `_userName` → `_channelId`；`syncFromIframe(channelId)`；WS 注册 `{channel: id}`
- `st_chat/__init__.py` — `ChatClient(user_name, channel_id)`；`send()` 通过 `ChannelRegistry.send_to_module()` 解析 `to_user → [channel_id]`
- `st_chat/frontend/build/index.html` — onRender 接收 `channelId`（传输层），payload 仍带 `fromUser`/`toUser`（业务层）
- `st_notify/__init__.py` — `send_notification()` 通过 `ChannelRegistry.send_to_module()` 解析 `to_user → [channel_id]`
- `demos/chat_script.py` / `demos/notification_script.py` — session_state 生成 `channel_id`，`ensure_registry_binding()` 绑定 user→channel

#### Added
- `st_push/registry.py` — `ChannelRegistry` 业务层单例，`generate_channel_id()` 工具函数

### [Unreleased]

#### Added
- `st_notify` 独立通知组件包 — 铃铛图标 + 弹窗，点击已读
- `st_chat` 独立聊天组件包 — 聊天窗口 UI
- `st_push/crypto.py` — AES-256-GCM 加密模块（cryptography 库 + XOR+HMAC stdlib 回退）
- 每连接加密握手：WS 注册时协商 32 字节随机密钥，后续消息全部加密
- `change.md` 合并踩坑记录与版本日志

#### Changed
- `st_push/hub.py` — 重构为高性能队列架构：per-connection `asyncio.Queue` + 后台 sender task，`call_soon_threadsafe` 替代阻塞 `run_coroutine_threadsafe`
- `st_push/routes.py` — 注册时生成 session key，ack 明文携带密钥，之后启用加密
- `st_push/frontend/build/index.html` — WS 连接+加密状态+模块回调提升到 `window.parent` 级别，独立于组件 iframe 生命周期
- `st_push/__init__.py` — `recv_msg()` 重命名为 `connect()`，移除离线缓冲
- 通知组件从 `st_push/modules/notification/` 迁移为独立的 `st_notify` 包
- 聊天 demo 从 `st_push` 内耦合迁移为独立的 `st_chat` 包
- 组件间通过 `st_push.register()` 获取 UUID，消息按 `targetModule` 路由，同名模块不冲突
- 文档结构重组：AGENTS.md 精简为核心规则，踩坑+变更移至 `change.md`，方案设计移至 `prd_*.md`，组件文档移至各组件 `README.md`

#### Removed
- `st_push/modules/` 目录（通知组件已迁移为独立的 `st_notify` 包）
- 离线缓冲机制（`_offline_buffers` / `deliver_offline_messages`）
- `recv_msg()` 方法（改为 `connect()`）

#### Fixed
- 通知组件不再以 toast 形式闪现，改为铃铛 + 弹窗 + 点击已读
- 模块注册竞态条件：st_push 未加载时，st_notify/st_chat 通过 `tryRegister()` 重试机制等待

#### Security
- WebSocket 传输从明文改为 AES-256-GCM 加密，每连接独立密钥

---

## v1 — 2026-07-14

### 重构概述

架构重构：统一协议帧、API 收口、传输层与业务层彻底解耦。

### Added

- **统一协议帧**：所有消息统一 `{type, moduleId, payload, ts, srcChannelId, targetChannelId}` 结构，按 `type` 驱动分发（register/ack/ping/pong/error/module_msg）
- **PushClient 收口**：构造时自动生成 channel_id + 绑定 user + 渲染传输组件（`connect()`），对外 API 统一
- **Module 委托模式**：Module 持有 PushClient 引用，`send_msg`/`broadcast_msg` 委托 client 发送
- **UserChannelManage**：重命名自 ChannelRegistry，删除 `exclude_channel`，仅服务于 PushClient，不对外暴露
- **模块注册幂等**：PushCore 按 name 去重（dict[name]），重复调用返回同 handle 同 UUID
- **prd_st_push_2.md**：v3.0 设计文档（背景/场景/Mermaid 类图/模块表/交互流程/分模块设计）

### Changed

- **协议消息命名规范化**：`st_push_ack`/`st_push`/`st_push_error`/`st_push_ping`/`st_push_pong` → 统一 `type` 字段
- **ack 帧结构调整**：sessionKey 从顶层移入 `payload` 子对象，符合统一帧规范
- **register 帧结构**：`{channel: "..."}` → `{type: "register", srcChannelId: "..."}`
- **st_chat/st_notify 适配**：ChatClient/NotificationClient 内部创建 PushClient（user-bound），register_module 幂等，send 用 `module.send_msg(payload, target_user=...)`
- **多端发送同步**：不排除 src_channelId，全部 target channel 都收到，前端去重（fromUser+toUser+content+ts）

### Removed

- **hub.py**：PushHub 合并到 push_core.py（PushCore + PushConnection + ModuleHandle）
- **registry.py**：ChannelRegistry 重命名移到 user_channel_manage.py（UserChannelManage），删除 `exclude_channel`/`send_to_module`/`send_to_user` 等业务方法
- **ModuleHandle.uuid**：改为 `module_id`，统一命名
- **ModuleHandle.send_to_channel/broadcast**：移入 PushClient.send_msg/broadcast_msg，Module 委托 client

### Fixed

- **心跳清理**：PushCore 心跳检测到 stale channel 时，调用 `UserChannelManage.cleanup_stale()` 清理 user-channel 映射
- **routes.py 清理**：连接断开时 finally 块统一调用 `core.unregister(conn)` + `ucm.cleanup_stale(channel_id)`

### Migration Guide

- `PushClient(channel_id)` → `PushClient(user="alice")`（自动生成 channel_id）
- `register("chat")` → `client.register_module("chat")`（PushClient 收口）
- `module.send_to_channel(payload, to_channel=...)` → `module.send_msg(payload, target_user=...)`（user-based 路由）
- `ChannelRegistry.instance().bind(...)` → `PushClient(user=...)` 自动绑定
- `registry.send_to_module(...)` → `module.send_msg(payload, target_user=...)`

---

## v2 — 2026-07-14

### Changed

- **PushClient session 单例**：新增 `get_or_create(user=...)` 类方法，保证一个 session 只创建一个 PushClient 实例（一个 WS 连接）。多个组件共享同一个实例
- **PushClient 注入模式**：st_chat/st_notify 不再内部创建 PushClient，改为构造函数首参注入。应用层创建一次，注入给所有组件
- **组件 user 绑定逻辑**：组件构造时先查询 `push_client.get_user()`，无则 bind，有则复用或 rebind
- **PushClient.get_user()**：新增查询方法，返回当前绑定的 user

### Migration Guide (v1 → v2)

- `ChatClient(user_name="alice")` → `ChatClient(push_client, user_name="alice")`
- `NotificationClient(user_name="alice")` → `NotificationClient(push_client, user_name="alice")`
- 应用层：`push_client = PushClient.get_or_create(user="alice")` 一次创建，注入给所有组件

---

## v3 — 2026-07-14

### Changed

- **chat/notify 作为 st_push 子组件打包**：`st_chat/` → `st_push/comp/chat/`，`st_notify/` → `st_push/comp/notify/`
- import 路径：`from st_chat import ChatClient` → `from st_push.comp.chat import ChatClient`，notify 同理
- 新增 `st_push/comp/__init__.py`（可选组件子包）
- demos/AGENTS.md/README 路径同步更新

### Migration Guide (v2 → v3)

- `from st_chat import ChatClient` → `from st_push.comp.chat import ChatClient`
- `from st_notify import NotificationClient` → `from st_push.comp.notify import NotificationClient`
- `import st_chat` → `import st_push.comp.chat`
- `import st_notify` → `import st_push.comp.notify`

---

## v4 — 2026-07-15

### Fixed

- **修复 notify 闭包陷阱**：`renderList()` 中 `var n` 是函数级作用域，循环结束后所有 onclick 闭包共享同一个 `n`，导致点击任意通知都只标记第一条已读、按钮都只取第一条的 actionUrl。改 `var` → `let`（块级作用域），每条通知的 onclick 绑定各自的 `n`。

### Changed

- **移除 `action_url`，改为 `payload`**：`NotificationPayload.action_url` → `payload`（类型 `Any`），`send_notification(action_url=...)` → `send_notification(payload=...)`。按钮点击不再做页面跳转，而是通过回调把 `payload` 传给 Python 侧由业务自行处理（可 `st.query_params` / `st.switch_page` / 其他逻辑）。

- **`render(on_click=callback) -> bool`**：新增 `on_click` 参数（`Callable[[Any], None]`），点击通知按钮时触发，接收 `payload`。返回 `bool` 表示本次 rerun 是否有点击被分发。通过 `notificationId` 在 `session_state` 去重，避免同一点击在多次 rerun 中重复触发回调。

- **前端按钮逻辑**：只有 `n.action` 非空时才显示按钮（不再要求 `action && actionUrl`）；点击按钮发送 `{action:"click", actionLabel, payload, notificationId}`。

### 踩坑：JS 闭包陷阱（var vs let）

**现象**：notify 弹窗中多条通知，只有第一条能点击标记已读，其余点击无效；带按钮的通知点击按钮也只触发第一条的 actionUrl。

**根因**：`for (var i = ...; i--) { var n = notifications[i]; ... item.onclick = function(){ markAsRead(n.id); } }` —— `var` 是函数级作用域，循环结束后 `n` 指向 `notifications[0]`，所有 onclick 闭包捕获的是同一个变量引用。

**修复**：`var` → `let`（ES6 块级作用域），每次迭代创建新的 `n` 绑定，闭包各自捕获。

**教训**：循环中绑定事件回调，务必用 `let`/`const`，不用 `var`。

### Migration Guide (v3 → v4)

- `send_notification(..., action_url="/task/123")` → `send_notification(..., action="查看任务", payload={"url": "/task/123"})`
- `NotificationPayload(action_url=...)` → `NotificationPayload(payload=...)`
- `action = notifier.render()` → `clicked = notifier.render(on_click=callback)`，回调签名 `callback(payload) -> None`
- 前端 `n.actionUrl` → `n.payload`
