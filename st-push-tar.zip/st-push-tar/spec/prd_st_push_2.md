# st_push 2.0 设计文档

## 1. 背景

Streamlit 的 `/_stcore/stream` WebSocket 承载 protobuf `ForwardMsg` delta，与脚本 rerun 生命周期紧耦合。用户代码无法按需推送，`ForwardMsg.parent_message` 只到达宿主页面，不转发到组件 iframe。

st_push 通过在 Streamlit 的 Starlette App 上挂载独立 WebSocket 路由 `/st_push/ws`，建立专用推送通道，绕过 delta/rerun 循环，实现真推送。

## 2. 支持场景

| 场景 | 说明 |
|------|------|
| 实时聊天 | 多用户实时收发消息，前端 callback 直接渲染，不触发 rerun |
| 站内通知 | 铃铛 + 弹窗，点击已读，服务端主动推送 |
| 多端登录同步 | 一个 user 多个 channel（多标签/多设备），消息推送到所有 channel |
| 多端发送同步 | 发送者发出的消息同步到自己的其他 channel |
| 模块化 pub/sub | 多组件共存，按 moduleId 路由，互不干扰 |
| 在线状态查询 | 查询 user/channel 是否在线 |
| 仅在线推送 | 离线返回 False，不缓冲，离线数据由端侧 GET 获取 |

## 3. 架构

```mermaid
classDiagram
    direction TB

    class PushCore {
        -_connections: dict
        -_modules: dict
        -_loop
        -_data_lock
        +instance() PushCore
        +register_channel(conn, channel_id) void
        +unregister(conn) void
        +send_msg(frame) bool
        +broadcast(frame) bool
        +register_module(name) ModuleHandle
        +is_online(channel_id) bool
        +get_all_connections() list
    }

    class PushConnection {
        +websocket
        +channel_id
        +session_key
        +encryption_enabled
        -_send_queue
        -_sender_task
        +init_queue(loop) void
        +enqueue(data, loop) bool
        +send_direct(data) bool
        +shutdown() void
    }

    class ModuleHandle {
        -_core
        +module_id
        +name
        +send_to_channel(payload, to_channel) bool
        +broadcast(payload) bool
    }

    class PushClient {
        -_core: PushCore
        -_ucm: UserChannelManage
        +channel_id
        +user
        -_modules: dict
        +connect() Any
        +bind_user(user) void
        +register_module(name) Module
        +send_msg(module, payload, target_user) bool
        +broadcast_msg(module, payload) bool
        +is_online(user) bool
    }

    class Module {
        -_client: PushClient
        +module_id
        +name
        +send_msg(payload, target_user) bool
        +broadcast_msg(payload) bool
    }

    class UserChannelManage {
        -_user_channels: dict
        -_channel_user: dict
        -_data_lock
        +instance() UserChannelManage
        +bind(user, channel_id) void
        +unbind(channel_id) void
        +get_channels(user) list
        +is_online(user) bool
        +cleanup_stale(channel_id) void
    }

    class PushRoutes {
        <<functions>>
        +create_push_routes() list
        +push_websocket_endpoint(ws) void
        +log_endpoint(request) JSONResponse
    }

    class Crypto {
        <<functions>>
        +generate_session_key() bytes
        +encrypt_message(key, data) str
        +decrypt_message(key, raw) str
        +is_encrypted_message(raw) bool
    }

    class FrontendSingleton {
        +_ws
        +_channelId
        +_encryptionReady
        +_callbacks
        +register(moduleId, callback)
        +dispatch(frame) bool
        +syncFromIframe(channelId) list
    }

    PushCore "1" *-- "0..*" PushConnection : channel to conn 1-1
    PushCore "1" *-- "0..*" ModuleHandle : name to handle
    PushCore "1" ..> "1" Crypto : encrypt decrypt
    PushClient --> PushCore : send_msg broadcast
    PushClient --> UserChannelManage : bind get_channels
    Module --> PushClient : delegate send
    PushRoutes ..> PushCore : register_channel
    PushRoutes ..> PushConnection : create
    PushRoutes ..> Crypto : handshake
    UserChannelManage --> PushCore : is_online check
    FrontendSingleton "1" -- "0..*" PushConnection : WebSocket
    FrontendSingleton "1" -- "0..*" ModuleHandle : callback dispatch
```

### 架构分层

| 层 | 模块 | 职责 | 知道 user？ |
|---|---|---|---|
| **传输层** | PushCore / PushConnection / PushRoutes / Crypto | channel→conn(1:1)、消息队列、加解密、心跳、WS 路由 | 否 |
| **业务层** | UserChannelManage | user→[channel_id](1:N) 路由解析、channel 生命周期 | 是 |
| **接入层** | PushClient / Module | 每 session 实例、生成 channelId、注册模块、对外 API | 是（payload 内） |

## 4. 核心模块概览表

| 模块 | 文件 | 层级 | 实例数 | 职责 |
|------|------|------|--------|------|
| PushCore | push_core.py | 传输层 | 全局 1 个 | 连接池、队列、心跳、模块注册（幂等）、广播 |
| PushConnection | push_core.py | 传输层 | 每 channel 1 个 | 封装单条 WS：队列 + sender task + 加密密钥 |
| ModuleHandle | push_core.py | 传输层 | 每模块 1 个 | 传输层模块句柄：send_to_channel / broadcast |
| PushClient | \_\_init\_\_.py | 接入层 | 每 session 1 个 | 生成 channelId、bind user、注册模块、send/broadcast |
| Module | \_\_init\_\_.py | 接入层 | 每 session 每模块 1 个 | 业务层模块句柄，委托 PushClient 发送 |
| UserChannelManage | user_channel_manage.py | 业务层 | 全局 1 个 | user→[channel] 映射、在线查询、生命周期清理 |
| PushRoutes | routes.py | 传输层 | — | WS 端点 + 日志端点，协议解析 |
| Crypto | crypto.py | 传输层 | — | AES-256-GCM + XOR/HMAC 回退 |
| Frontend | frontend/build/index.html | 前端 | 每 tab 1 个 | WS 客户端、加解密、callback 分发 |

## 5. 交互流程

### 5.1 连接生命周期

```
启动器: App(routes=st_push.create_push_routes())
  → Starlette 挂载 /st_push/ws + /st_push/log

脚本: PushClient(user="alice")
  → 生成 channel_id
  → ucm.bind("alice", channel_id)
  → connect() 渲染不可见组件
    → 前端 iframe 注入 parent 上下文
    → 前端 new WebSocket("/st_push/ws")
    → onopen → 发送 register 帧
    → 服务端 register_channel(conn, channel_id)
    → 服务端生成 sessionKey → 发送 ack 帧（明文）
    → 前端收到 ack → 启用加密
    → 连接就绪
```

### 5.2 加密握手

```
C → S: {type:"register", srcChannelId:"ch-abc"}          ← 明文，唯一不加密的消息
S → C: {type:"ack", payload:{sessionKey:..., algo:...}}   ← 明文，携带密钥
S:    conn.encryption_enabled = True                       ← ack 发送后才启用
C:    stp._encryptionReady = true
后续:  双向全部加密
```

### 5.3 模块消息发送（模块事件）

```
Module.send_msg(payload, target_user="bob")
  → PushClient.send_msg(self, payload, "bob")
    → 构造帧: {type:"module_msg", moduleId, payload, ts, srcChannelId}
    → ucm.get_channels("bob") → ["ch-x", "ch-y"]        ← 多端拆多条
    → 每个目标 channel 填入 targetChannelId
    → core.send_msg(frame) × N
      → conn.enqueue(frame, loop)
        → call_soon_threadsafe(queue.put_nowait)
          → sender_task: encrypt → websocket.send_text()

前端收到:
  ws.onmessage → decrypt → parse frame
    → type=="module_msg" → dispatch(moduleId, payload)
      → callback(payload, frame) → 直接操作 DOM（不 rerun）
```

### 5.4 不指定 target_user 的发送

```
Module.send_msg(payload)  ← 不指定 target_user
  → PushClient.send_msg(self, payload, None)
    → if self.user: ucm.get_channels(self.user) → 所有 channel（含自己）
    → else: target = src_channelId（发给自己）
    → 不排除 src_channelId，全部 channel 都收到
```

### 5.5 心跳机制

```
PushCore 后台任务（每 60s）:
  遍历所有 PushConnection
    → 发送 {type:"ping", ts} 入队
    → 检查 last_pong，超过 120s 无 pong:
      → conn.shutdown()
      → core.unregister(conn)
      → ucm.cleanup_stale(channel_id)

前端收到:
  {type:"ping"} → 回复 {type:"pong", ts}（加密）
```

### 5.6 多端发送同步

```
alice(channel_A) 发消息给 bob
  → ucm.get_channels("bob") → [ch_B1, ch_B2]          ← bob 的多端
  → 投递给 ch_B1, ch_B2

不指定 target_user 时（发给自己所有 channel）:
  → ucm.get_channels("alice") → [ch_A, ch_A2, ch_A3]
  → 投递给全部（含发起方 ch_A，不排除）
```

## 6. 分模块设计

### 6.1 PushCore（push_core.py）

传输层全局单例。管理连接池、消息队列、心跳、模块注册。

```python
class PushCore:
    _instance / _lock                          # 单例

    _connections: dict[str, PushConnection]     # channelId → conn (1:1)
    _modules: dict[str, ModuleHandle]           # name → handle (幂等去重)
    _loop: AbstractEventLoop                    # server loop 引用
    _data_lock: threading.Lock                  # register/unregister 锁
    _heartbeat_task: asyncio.Task

    # --- 连接管理 ---
    def register_channel(conn, channel_id)     # 前端注册，建立 channelId→conn
    def unregister(conn)                        # 移除连接
    def is_online(channel_id) -> bool          # 查询
    def get_all_connections() -> list           # 广播用

    # --- 消息投递 ---
    def send_msg(frame: dict) -> bool           # 投递到 frame.targetChannelId
    def broadcast(frame: dict) -> bool          # 广播所有在线 channel

    # --- 模块注册（幂等） ---
    def register_module(name: str) -> ModuleHandle
        # 按 name 去重：已存在则返回已有 handle，不生成新 UUID

    # --- 心跳 ---
    async def _heartbeat_loop()                 # 60s ping + 120s 清理
```

### 6.2 PushConnection（push_core.py）

单条 WebSocket 连接封装。**保留现有实现，不改动。**

```python
class PushConnection:
    websocket: Any
    channel_id: str
    session_key: bytes                          # 32 字节 AES 密钥
    encryption_enabled: bool
    _send_queue: asyncio.Queue(maxsize=1000)
    _sender_task: asyncio.Task

    def init_queue(loop)                        # 初始化队列 + 启动 sender task
    def enqueue(data, loop) -> bool             # call_soon_threadsafe 入队（非阻塞）
    async def send_direct(data) -> bool         # 直接发送（ack/error 用，不经队列）
    async def shutdown()                        # 取消 sender + 关闭连接
    def update_pong()                           # 标记收到 pong
    def is_heartbeat_stale(timeout=120) -> bool
```

### 6.3 PushClient（\_\_init\_\_.py）

每 session 一个实例。对外 API 入口。

```python
class PushClient:
    _core: PushCore
    _ucm: UserChannelManage
    channel_id: str                            # 生成时确定
    user: Optional[str]                        # bind 时的 user
    _modules: dict[str, Module]                 # session 级缓存 name→Module

    def __init__(self, user: Optional[str] = None)
        # 1. 生成 channel_id
        # 2. 若 user 指定 → ucm.bind(user, channel_id)
        # 3. 直接调 connect() 渲染不可见组件

    def connect() -> Any                        # 渲染 WS 传输组件（height=0）

    def bind_user(self, user: str)              # 后绑定/切换 user

    def register_module(self, name: str) -> Module
        # 幂等：session 内 name 缓存
        # 首次调 core.register_module(name) 获取 moduleId

    def send_msg(self, module: Module, payload, target_user=None) -> bool
        # 构造帧: {type:"module_msg", moduleId, payload, ts, srcChannelId}
        # target_user 指定 → ucm.get_channels(target_user)，多个拆多条
        # target_user 不指定:
        #   self.user 存在 → ucm.get_channels(self.user) → 全部 channel
        #   self.user 不存在 → target = src_channelId（发给自己）
        # 不排除 src_channelId
        # 每条调 core.send_msg(frame)

    def broadcast_msg(self, module: Module, payload) -> bool
        # 构造帧，调 core.broadcast(frame)

    def is_online(self, user: str) -> bool
        # 委托 ucm.is_online(user)
```

### 6.4 Module（\_\_init\_\_.py）

业务层模块句柄。持有 PushClient 引用，委托发送。

```python
class Module:
    _client: PushClient
    module_id: str
    name: str

    def send_msg(self, payload, target_user=None) -> bool
        # 委托: return self._client.send_msg(self, payload, target_user)

    def broadcast_msg(self, payload) -> bool
        # 委托: return self._client.broadcast_msg(self, payload)
```

### 6.5 UserChannelManage（user_channel_manage.py）

业务层全局单例。user→[channel] 映射，服务 PushClient，不对外暴露。

```python
class UserChannelManage:
    _instance / _lock

    _user_channels: dict[str, set[str]]         # user → {channel_id} (1:N)
    _channel_user: dict[str, str]               # channel_id → user（反向查找）

    def bind(user, channel_id)                  # 绑定，切换 user 时自动迁移
    def unbind(channel_id)                      # 移除
    def get_channels(user) -> list[str]
    def is_online(user) -> bool                 # user 是否有在线 channel
    def cleanup_stale(channel_id)              # pushCore 心跳清理时回调
```

### 6.6 PushRoutes（routes.py）

WS 端点 + 日志端点。按 type 分发协议。

```python
async def push_websocket_endpoint(websocket):
    # accept → core.set_loop → create PushConnection → init_queue
    while True:
        raw = await websocket.receive_text()
        # 解密（若 encryption_enabled）
        frame = json.loads(raw)
        # 按 type 分发:
        #   "register"   → core.register_channel(conn, frame.srcChannelId)
        #                 → 生成 sessionKey → conn.send_direct(ack 帧)
        #                 → conn.encryption_enabled = True
        #   "pong"       → conn.update_pong()
        #   "module_msg" → core.send_msg(frame)（按 targetChannelId 投递）

def create_push_routes() -> list
    # [WebSocketRoute("/st_push/ws"), Route("/st_push/log")]
```

### 6.7 Crypto（crypto.py）

**保留现有实现，不改动。**

```python
def generate_session_key() -> bytes             # 32 字节随机密钥
def encrypt_message(key, data) -> str           # AES-256-GCM 或 XOR+HMAC 回退
def decrypt_message(key, raw) -> Optional[str]
def is_encrypted_message(raw) -> bool
```

### 6.8 Frontend（frontend/build/index.html）

WS 客户端 + 加解密 + callback 分发。保留 WS 重连/退避/parent 注入骨架，协议帧格式按新规范。

```javascript
// 协议帧构造
function buildFrame(type, opts) {
    return {
        type: type,
        moduleId: opts.moduleId || null,
        payload: opts.payload || null,
        ts: opts.ts || Date.now() / 1000,
        srcChannelId: opts.srcChannelId || stp._channelId,
        targetChannelId: opts.targetChannelId || null
    };
}

// 消息处理（按 type 分发）
stp._handleMessage = function(rawStr) {
    var frame = JSON.parse(rawStr);
    switch(frame.type) {
        case "ack":         // 提取 sessionKey → 启用加密
        case "ping":        // 回复 pong
        case "module_msg":  // dispatch(frame.moduleId, frame.payload, frame)
        case "error":       // 日志
    }
};

// 模块 callback 注册（保留）
stp.register = function(moduleId, callback) { ... }
stp.dispatch = function(frame) { ... }
```

### 6.9 协议规范

#### 帧结构

```
{
  "type":          string,   // 必填
  "moduleId":      string,   // module_msg 必填，其余可选
  "payload":       any,      // module_msg 必填，ack/error 用，其余可选
  "ts":            float,    // module_msg/ping 必填，其余可选
  "srcChannelId":  string,   // register/module_msg 必填，其余可选
  "targetChannelId": string  // module_msg 必填，其余可选
}
```

#### 消息类型

| type | 方向 | 必填字段 | 用途 |
|------|------|---------|------|
| `register` | C→S | srcChannelId | 前端注册 channel |
| `ack` | S→C | srcChannelId, payload(sessionKey, algo) | 注册确认 + 密钥交换（明文） |
| `ping` | S→C | ts | 心跳探测 |
| `pong` | C→S | ts | 心跳回复 |
| `error` | S→C | payload(msg) | 错误通知 |
| `module_msg` | 双向 | moduleId, payload, ts, srcChannelId, targetChannelId | 模块消息 |

#### 加密规则

- `register` 和 `ack`：明文（密钥交换前）
- 其余所有消息：AES-256-GCM 加密（或 XOR+HMAC 回退）
- wire 格式：`{"v":1, "algo":"aes-gcm", "n":"<base64 nonce>", "c":"<base64 ct+tag>"}`
