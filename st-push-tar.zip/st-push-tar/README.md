# st-push

Streamlit 实时推送组件 — WebSocket 路由挂载到 Starlette App，真推送，AES-256-GCM 加密，模块路由多组件共存。

## 背景

Streamlit 原生 rerun 模型不适合高频实时数据推送。st-push 通过在 Streamlit 的 Starlette App 上挂载 WebSocket 路由，建立服务端到浏览器的加密长连接，实现真推送（前端 callback 直接处理，不触发 rerun）。

## 特性

- **真推送**：WebSocket 长连接，前端 callback 直接处理消息，不触发 rerun
- **加密**：每连接独立 AES-256-GCM 密钥，自动回退 XOR+HMAC
- **模块路由**：多组件共存，按 moduleId 分发消息
- **多端登录**：user→[channel] 1:N 映射，消息推送到用户所有设备
- **多端发送同步**：发送消息时 echo 给发送者所有 channel，前端去重
- **PushClient session 单例**：公共基础设施，应用层创建一次注入所有组件

## 架构分层

| 层 | 模块 | 职责 |
|----|------|------|
| 传输层 | `push_core.py` / `routes.py` / `crypto.py` | channel→conn(1:1)，加密，心跳，模块路由 |
| 业务层 | `user_channel_manage.py` | user→[channel_id](1:N) 多端登录映射 |
| 接入层 | `__init__.py` | PushClient（session 单例）+ Module |

## 使用步骤

### 1. 安装

本模块未发布到 PyPI，从源码构建安装：

```bash
git clone <repo>
cd st-push
python -m build
pip install dist/st_push-1.0-py3-none-any.whl
```

或开发模式安装：

```bash
pip install -e .
```

### 2. 启动器：挂载 WebSocket 路由

```python
# app.py
from streamlit.web.server.starlette import App
import st_push

app = App("script.py", routes=st_push.create_push_routes())
if __name__ == "__main__":
    app.run()
```

### 3. 脚本：创建 PushClient + 使用组件

```python
import streamlit as st
from st_push import PushClient
from st_push.comp.chat import ChatClient
from st_push.comp.notify import NotificationClient

# 应用层创建公共 PushClient（session 单例）
push_client = PushClient.session_instance(user="alice")

# 注入给组件
chat = ChatClient(push_client, user_name="alice")
notifier = NotificationClient(push_client, user_name="alice")

# 渲染 + 发送
chat.render(peer="bob")
notifier.render()
chat.send("Hello!", to_user="bob")
notifier.send_notification(to_user="bob", title="新任务", body="修复登录Bug")
```

### 4. 运行

```bash
python app.py
```

## 支持的组件

| 组件 | 路径 | 说明 |
|------|------|------|
| ChatClient | `st_push.comp.chat` | 聊天窗口 UI，实时收发消息 |
| NotificationClient | `st_push.comp.notify` | 铃铛图标 + 弹窗通知，点击已读 |

## 文档

| 文档 | 内容 |
|------|------|
| [st_push/README.md](st_push/README.md) | API 文档（PushClient / Module / PushCore / UserChannelManage） |
| [spec/st_push接入指南.md](spec/st_push接入指南.md) | 接入指南 + 自定义组件开发 |
| [st_push/comp/chat/README.md](st_push/comp/chat/README.md) | 聊天组件文档 |
| [st_push/comp/notify/README.md](st_push/comp/notify/README.md) | 通知组件文档 |
| [spec/prd_st_push_2.md](spec/prd_st_push_2.md) | v3.0 设计文档 |
| [spec/change.md](spec/change.md) | 踩坑记录 + 版本变更日志 |

## 演示

```bash
python demos/chat_app.py          # 聊天演示
python demos/notification_app.py  # 通知演示
```

## License

MIT
