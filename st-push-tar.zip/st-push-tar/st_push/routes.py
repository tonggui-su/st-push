"""
st_push WebSocket route definitions (v3.0 — type-driven protocol).

These routes are mounted onto Streamlit's Starlette App via:
    App(routes=st_push.create_push_routes())

Route: /st_push/ws (WebSocket)

Protocol 3.0 — unified frame:
    {type, moduleId, payload, ts, srcChannelId, targetChannelId}

  type drives dispatch:
    - register : client → server (plaintext, carries srcChannelId)
    - ack      : server → client (plaintext, carries sessionKey in payload)
    - ping     : server → client (heartbeat)
    - pong     : client → server (heartbeat response)
    - error    : server → client (plaintext errors)
    - module_msg : bidirectional (encrypted), carries moduleId + payload

Per-connection encryption:
  - On register, the server generates a 32-byte session key
  - The key is sent to the client in the ack frame's payload (base64)
  - All subsequent messages in both directions are encrypted
  - The register + ack frames are plaintext (key exchange)
"""
from __future__ import annotations

import asyncio
import base64
import json
import time
from typing import Any

from starlette.routing import WebSocketRoute, Route
from starlette.websockets import WebSocket, WebSocketDisconnect
from starlette.requests import Request
from starlette.responses import JSONResponse

from streamlit.logger import get_logger

from st_push.push_core import PushCore, PushConnection
from st_push.crypto import (
    generate_session_key,
    decrypt_message,
    is_encrypted_message,
    has_aes_gcm,
)

_LOGGER = get_logger(__name__)


async def push_websocket_endpoint(websocket: WebSocket) -> None:
    """Handle /st_push/ws WebSocket connections (v3.0 type-driven protocol).

    Message flow:
      Client → Server (plaintext, pre-registration):
        {"type": "register", "srcChannelId": "ch-abc123"}

      Client → Server (encrypted, post-registration):
        {"type": "pong", "ts": ...}
        {"type": "module_msg", "moduleId": "...", "payload": ..., "targetChannelId": "..."}

      Server → Client:
        {"type": "ack", "srcChannelId": "...", "payload": {"sessionKey": "...", "algo": "..."}, "ts": ...}
        {"type": "ping", "ts": ...}
        {"type": "error", "payload": {"msg": "not registered"}}
        {"type": "module_msg", ...}  (encrypted)
    """
    client_host = websocket.client.host if websocket.client else "unknown"
    client_port = websocket.client.port if websocket.client else 0
    _LOGGER.info(
        "WS endpoint: new connection from %s:%s", client_host, client_port,
    )

    await websocket.accept()
    _LOGGER.debug("WS endpoint: connection accepted from %s:%s", client_host, client_port)

    core = PushCore.instance()
    core.set_loop(asyncio.get_running_loop())

    conn = PushConnection(websocket)
    conn.init_queue(asyncio.get_running_loop())
    _LOGGER.debug(
        "WS endpoint: PushConnection created for %s:%s", client_host, client_port,
    )

    try:
        while True:
            raw = await websocket.receive_text()
            _LOGGER.debug(
                "WS endpoint: ← received %d bytes from %s:%s",
                len(raw), client_host, client_port,
            )

            # If encryption is enabled, decrypt incoming messages
            if conn.encryption_enabled and conn.session_key:
                if is_encrypted_message(raw):
                    plaintext = decrypt_message(conn.session_key, raw)
                    if plaintext is None:
                        _LOGGER.warning(
                            "WS endpoint: decrypt FAILED from %s:%s — dropping",
                            client_host, client_port,
                        )
                        continue
                    raw = plaintext.decode("utf-8")
                else:
                    # Plaintext after encryption is enabled — could be a
                    # re-registration (client reconnects without dropping WS).
                    _LOGGER.debug(
                        "WS endpoint: plaintext msg after encryption enabled from %s:%s",
                        client_host, client_port,
                    )

            try:
                data: dict[str, Any] = json.loads(raw)
            except json.JSONDecodeError:
                _LOGGER.warning(
                    "WS endpoint: JSON parse failed from %s:%s raw=%s",
                    client_host, client_port, raw[:100],
                )
                continue

            msg_type = data.get("type")

            if msg_type == "register":
                # --- Registration / re-registration ---
                channel_id = str(data.get("srcChannelId", ""))
                if not channel_id:
                    _LOGGER.warning(
                        "WS endpoint: register with no srcChannelId from %s:%s",
                        client_host, client_port,
                    )
                    await conn.send_direct({
                        "type": "error",
                        "payload": {"msg": "register: missing srcChannelId"},
                        "ts": time.time(),
                    })
                    continue

                _LOGGER.info(
                    "WS endpoint: register request channel=%s from %s:%s",
                    channel_id[:12], client_host, client_port,
                )

                # Generate per-connection session key
                session_key = generate_session_key()
                conn.session_key = session_key
                # NOTE: encryption_enabled is set AFTER the ack is sent,
                # because the ack carries the key — client can't decrypt
                # until it receives the ack.

                core.register_channel(conn, channel_id)

                # Send ack with session key (plaintext — this is the key exchange)
                algo = "aes-gcm" if has_aes_gcm() else "xor-hmac"
                ack_frame = {
                    "type": "ack",
                    "srcChannelId": channel_id,
                    "payload": {
                        "sessionKey": base64.b64encode(session_key).decode("ascii"),
                        "algo": algo,
                        "msg": "registered",
                    },
                    "ts": time.time(),
                }
                _LOGGER.info(
                    "WS endpoint: → sending ack channel=%s algo=%s",
                    channel_id[:12], algo,
                )
                await conn.send_direct(ack_frame)

                # Now enable encryption for all subsequent messages
                conn.encryption_enabled = True

            elif msg_type == "pong":
                # --- Heartbeat pong response ---
                conn.update_pong()
                _LOGGER.debug(
                    "WS endpoint: ← pong from channel=%s",
                    conn.channel_id[:12] if conn.channel_id else "(unregistered)",
                )

            elif msg_type == "module_msg":
                # --- Encrypted module message from client ---
                if conn.channel_id is None:
                    _LOGGER.warning(
                        "WS endpoint: module_msg from unregistered connection %s:%s",
                        client_host, client_port,
                    )
                    await conn.send_direct({
                        "type": "error",
                        "payload": {"msg": "not registered"},
                        "ts": time.time(),
                    })
                    continue

                module_id = data.get("moduleId", "")
                payload = data.get("payload")
                target_channel = data.get("targetChannelId")
                src_channel = data.get("srcChannelId") or conn.channel_id
                ts = data.get("ts", time.time())

                _LOGGER.info(
                    "WS endpoint: ← module_msg from=%s module=%s target=%s",
                    src_channel[:12], module_id[:8] if module_id else "?",
                    target_channel[:12] if target_channel else "(broadcast)",
                )

                if target_channel:
                    # Route to specific target channel
                    frame = {
                        "type": "module_msg",
                        "moduleId": module_id,
                        "payload": payload,
                        "ts": ts,
                        "srcChannelId": src_channel,
                        "targetChannelId": target_channel,
                    }
                    core.send_msg(frame)
                else:
                    # Broadcast to all online channels
                    frame = {
                        "type": "module_msg",
                        "moduleId": module_id,
                        "payload": payload,
                        "ts": ts,
                        "srcChannelId": src_channel,
                        "targetChannelId": None,
                    }
                    core.broadcast(frame)

            else:
                _LOGGER.debug(
                    "WS endpoint: unknown/unhandled type=%s from %s:%s keys=%s",
                    msg_type or "(none)", client_host, client_port, list(data.keys()),
                )

    except WebSocketDisconnect:
        _LOGGER.info(
            "WS endpoint: disconnected channel=%s from %s:%s",
            conn.channel_id or "(unregistered)", client_host, client_port,
        )
    except Exception as e:
        _LOGGER.warning(
            "WS endpoint: unexpected error channel=%s error=%s",
            conn.channel_id or "(unregistered)", e,
        )
    finally:
        _LOGGER.debug(
            "WS endpoint: cleanup for %s:%s channel=%s",
            client_host, client_port, conn.channel_id or "(none)",
        )
        await conn.shutdown()
        core.unregister(conn)
        # Clean up user-channel mapping for stale channel
        if conn.channel_id:
            from st_push.user_channel_manage import UserChannelManage
            UserChannelManage.instance().cleanup_stale(conn.channel_id)


def create_push_routes() -> list:
    """Create the route list for st_push v3.0.

    Routes:
      - POST /st_push/log   : Frontend remote log ingestion
      - WS   /st_push/ws    : Push WebSocket endpoint
    """
    _LOGGER.info("create_push_routes: registering routes /st_push/ws + /st_push/log")
    return [
        WebSocketRoute("/st_push/ws", push_websocket_endpoint),
        Route("/st_push/log", log_endpoint, methods=["POST"]),
    ]


async def log_endpoint(request: Request) -> JSONResponse:
    """POST /st_push/log — Frontend remote log ingestion endpoint."""
    try:
        body = await request.json()
    except Exception as e:
        _LOGGER.warning("log_endpoint: failed to parse JSON body: %s", e)
        return JSONResponse({"ok": False, "error": "invalid json"}, status_code=400)

    if isinstance(body, dict):
        entries = [body]
    elif isinstance(body, list):
        entries = body
    else:
        return JSONResponse({"ok": False, "error": "expected object or array"}, status_code=400)

    client_host = request.client.host if request.client else "unknown"

    for entry in entries:
        if not isinstance(entry, dict):
            continue

        component = str(entry.get("component", "unknown"))
        level = str(entry.get("level", "info")).lower()
        msg = str(entry.get("msg", ""))
        data = entry.get("data", {})
        ts = entry.get("ts", "")

        prefix = "[{}] [client:{}]".format(component, client_host)
        log_line = "{} {}".format(msg, _format_data(data)) if data else msg

        if level == "error":
            _LOGGER.error("%s %s", prefix, log_line)
        elif level == "warn":
            _LOGGER.warning("%s %s", prefix, log_line)
        elif level == "debug":
            _LOGGER.debug("%s %s", prefix, log_line)
        else:
            _LOGGER.info("%s %s", prefix, log_line)

    return JSONResponse({"ok": True, "ingested": len(entries)})


def _format_data(data: Any) -> str:
    """Compact string representation of log data dict."""
    try:
        import json as _json
        return _json.dumps(data, ensure_ascii=False, default=str)
    except Exception:
        return str(data)
