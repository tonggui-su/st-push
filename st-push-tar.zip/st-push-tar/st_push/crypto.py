"""
Encryption module for st_push WebSocket transport.

Each WebSocket connection negotiates a per-session secret key during the
initial handshake. All subsequent messages on that connection are encrypted
to prevent eavesdropping and tampering.

Two backends:
  1. AES-256-GCM via the `cryptography` library (preferred)
     - Provides confidentiality + authenticity
     - 12-byte random nonce per message
     - 16-byte authentication tag

  2. XOR + HMAC-SHA256 stdlib fallback (always available)
     - HMAC-SHA256 for integrity (keyed hash)
     - XOR for confidentiality (not cryptographically secure against
       known-plaintext, but adequate as a fallback)
     - No external dependencies

The wire format is JSON: {"v": 1, "n": "<base64 nonce>", "c": "<base64 ciphertext>", "h": "<base64 hmac>"}
For AES-GCM, the tag is appended to ciphertext (GCM standard).
For XOR fallback, HMAC is computed over nonce+ciphertext.

Key derivation:
  - The server generates a 32-byte random secret at connection time
  - The raw secret is base64-encoded and sent to the client in the
    registration ack (over the just-established WebSocket)
  - Both sides use this raw key for encryption/decryption
"""
from __future__ import annotations

import base64
import hashlib
import hmac
import json
import os
import secrets
from typing import Optional

# Detect cryptography library
try:
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM
    _HAS_CRYPTOGRAPHY = True
except ImportError:
    _HAS_CRYPTOGRAPHY = False


def has_aes_gcm() -> bool:
    """Return True if the `cryptography` library with AES-GCM is available."""
    return _HAS_CRYPTOGRAPHY


def generate_session_key() -> bytes:
    """Generate a 32-byte (256-bit) random session key."""
    return secrets.token_bytes(32)


def generate_session_key_b64() -> str:
    """Generate a session key and return it as base64 string."""
    return base64.b64encode(generate_session_key()).decode("ascii")


def derive_hmac_key(session_key: bytes) -> bytes:
    """Derive a 32-byte HMAC key from the session key using HKDF-like derivation."""
    return hashlib.sha256(session_key + b"st_push_hmac_key").digest()


def derive_xor_key(session_key: bytes) -> bytes:
    """Derive a 32-byte XOR key from the session key."""
    return hashlib.sha256(session_key + b"st_push_xor_key").digest()


def _xor(data: bytes, key: bytes) -> bytes:
    """XOR data with a repeating key."""
    kl = len(key)
    return bytes(b ^ key[i % kl] for i, b in enumerate(data))


def encrypt_message(session_key: bytes, plaintext: bytes) -> str:
    """Encrypt plaintext and return a JSON wire-format string.

    Uses AES-256-GCM if available, otherwise XOR+HMAC fallback.
    """
    nonce = secrets.token_bytes(12 if _HAS_CRYPTOGRAPHY else 16)

    if _HAS_CRYPTOGRAPHY:
        aesgcm = AESGCM(session_key)
        # AESGCM.encrypt returns ciphertext + 16-byte tag appended
        ct_with_tag = aesgcm.encrypt(nonce, plaintext, None)
        wire = {
            "v": 1,
            "algo": "aes-gcm",
            "n": base64.b64encode(nonce).decode("ascii"),
            "c": base64.b64encode(ct_with_tag).decode("ascii"),
        }
    else:
        xor_key = derive_xor_key(session_key)
        hmac_key = derive_hmac_key(session_key)
        ciphertext = _xor(plaintext, xor_key)
        mac = hmac.new(hmac_key, nonce + ciphertext, hashlib.sha256).digest()
        wire = {
            "v": 1,
            "algo": "xor-hmac",
            "n": base64.b64encode(nonce).decode("ascii"),
            "c": base64.b64encode(ciphertext).decode("ascii"),
            "h": base64.b64encode(mac).decode("ascii"),
        }

    return json.dumps(wire, separators=(",", ":"))


def decrypt_message(session_key: bytes, wire_str: str) -> Optional[bytes]:
    """Decrypt a wire-format JSON string and return plaintext bytes.

    Returns None if the message is invalid (bad HMAC, wrong key, etc.).
    """
    try:
        wire = json.loads(wire_str)
    except (json.JSONDecodeError, TypeError):
        return None

    if not isinstance(wire, dict) or wire.get("v") != 1:
        return None

    algo = wire.get("algo", "aes-gcm")
    nonce_b64 = wire.get("n", "")
    ct_b64 = wire.get("c", "")

    try:
        nonce = base64.b64decode(nonce_b64)
        ct = base64.b64decode(ct_b64)
    except Exception:
        return None

    if algo == "aes-gcm" and _HAS_CRYPTOGRAPHY:
        try:
            aesgcm = AESGCM(session_key)
            return aesgcm.decrypt(nonce, ct, None)
        except Exception:
            return None

    elif algo == "xor-hmac":
        hmac_key = derive_hmac_key(session_key)
        expected_mac = hmac.new(hmac_key, nonce + ct, hashlib.sha256).digest()
        given_mac_b64 = wire.get("h", "")
        try:
            given_mac = base64.b64decode(given_mac_b64)
        except Exception:
            return None
        if not hmac.compare_digest(expected_mac, given_mac):
            return None
        xor_key = derive_xor_key(session_key)
        return _xor(ct, xor_key)

    return None


def is_encrypted_message(raw: str) -> bool:
    """Check if a raw string looks like an encrypted wire-format message."""
    if not raw or raw[0] != "{":
        return False
    try:
        d = json.loads(raw)
        return isinstance(d, dict) and d.get("v") == 1 and "c" in d
    except (json.JSONDecodeError, TypeError):
        return False


__all__ = [
    "has_aes_gcm",
    "generate_session_key",
    "generate_session_key_b64",
    "encrypt_message",
    "decrypt_message",
    "is_encrypted_message",
]
