"""
PushCore — Transport-layer singleton for st_push 2.0.

Manages channel→WebSocket connection mapping (1:1), per-connection message
queues, background sender tasks, heartbeat-based stale connection cleanup,
and module registration (idempotent by name).

Design philosophy:
  PUSH = online-only real-time delivery
  - If the target channel is online → enqueue message to its asyncio.Queue,
    return True immediately (fire-and-forget)
  - If the target channel is offline → return False immediately (no buffering)
  - Offline data retrieval is the responsibility of the client (GET pattern)

High-performance queue architecture (preserved from v2):
  - Each PushConnection has an asyncio.Queue and a background sender task
  - send_msg() enqueues via call_soon_threadsafe() (no blocking)
  - The sender task drains the queue and writes to the WebSocket
  - No threading.Lock on the hot path — only a lightweight dict lock for
    register/unregister (infrequent)

Protocol 2.0:
  All messages use a unified frame structure:
    {type, moduleId, payload, ts, srcChannelId, targetChannelId}
  type drives dispatch: register, ack, ping, pong, error, module_msg

Module registration:
  Idempotent by name. Calling register_module("chat") multiple times
  returns the same ModuleHandle with the same module_id.
"""
from __future__ import annotations

import asyncio
import json
import threading
import time
import uuid
from typing import Any, Optional

from streamlit.logger import get_logger

from st_push.crypto import (
    encrypt_message,
    decrypt_message,
    generate_session_key,
    is_encrypted_message,
)

_LOGGER = get_logger(__name__)


class PushConnection:
    """Wraps a single frontend WebSocket connection with a send queue.

    Preserved from v2 — queue architecture, sender task, encryption,
    and shutdown logic are unchanged.
    """

    def __init__(self, websocket: Any) -> None:
        self.websocket = websocket
        self.channel_id: Optional[str] = None
        self.connected_at: float = time.time()
        self.last_pong: float = time.time()

        self.session_key: Optional[bytes] = None
        self.encryption_enabled: bool = False

        self._send_queue: Optional[asyncio.Queue] = None
        self._sender_task: Optional[asyncio.Task] = None

    def init_queue(self, loop: asyncio.AbstractEventLoop) -> None:
        self._send_queue = asyncio.Queue(maxsize=1000)
        self._sender_task = loop.create_task(self._sender_loop())
        _LOGGER.debug(
            "init_queue: sender task started for channel=%s",
            self.channel_id or "(unregistered)",
        )

    def update_pong(self) -> None:
        self.last_pong = time.time()

    def is_heartbeat_stale(self, timeout: float = 120.0) -> bool:
        return (time.time() - self.last_pong) > timeout

    async def _sender_loop(self) -> None:
        ch_id = self.channel_id or "(unregistered)"
        _LOGGER.info("sender_loop: started for channel=%s", ch_id)
        try:
            while True:
                data = await self._send_queue.get()
                if data is None:
                    _LOGGER.info("sender_loop: shutdown signal for channel=%s", ch_id)
                    break

                try:
                    raw = json.dumps(data, ensure_ascii=False, default=str)
                    enc_state = "encrypted" if (self.encryption_enabled and self.session_key) else "plaintext"
                    if self.encryption_enabled and self.session_key:
                        raw = encrypt_message(self.session_key, raw.encode("utf-8"))
                    await self.websocket.send_text(raw)
                    _LOGGER.info(
                        "sender_loop: SENT channel=%s type=%s moduleId=%s enc=%s srcCh=%s tgtCh=%s",
                        self.channel_id,
                        data.get("type", "?"),
                        (data.get("moduleId") or "-")[:8] if data.get("moduleId") else "-",
                        enc_state,
                        (data.get("srcChannelId") or "-")[:12] if data.get("srcChannelId") else "-",
                        (data.get("targetChannelId") or "-")[:12] if data.get("targetChannelId") else "-",
                    )
                except Exception as e:
                    _LOGGER.warning(
                        "sender_loop: send FAILED channel=%s error=%s",
                        self.channel_id, e,
                    )
                    break
        except asyncio.CancelledError:
            _LOGGER.info("sender_loop: cancelled for channel=%s", ch_id)
        except Exception as e:
            _LOGGER.warning("sender_loop: unexpected error channel=%s error=%s", ch_id, e)
        finally:
            _LOGGER.info("sender_loop: exited for channel=%s", ch_id)

    def enqueue(self, data: dict, loop: asyncio.AbstractEventLoop) -> bool:
        if self._send_queue is None:
            _LOGGER.warning("enqueue: queue not initialized for channel=%s", self.channel_id)
            return False

        def _do_enqueue():
            try:
                self._send_queue.put_nowait(data)
                _LOGGER.info(
                    "enqueue: PUT OK channel=%s type=%s qsize=%d",
                    self.channel_id,
                    data.get("type", "?"),
                    self._send_queue.qsize(),
                )
            except asyncio.QueueFull:
                _LOGGER.warning(
                    "enqueue: queue full (maxsize=1000) channel=%s — message dropped",
                    self.channel_id,
                )

        loop.call_soon_threadsafe(_do_enqueue)
        return True

    async def send_direct(self, data: dict) -> bool:
        try:
            raw = json.dumps(data, ensure_ascii=False, default=str)
            enc_state = "encrypted" if (self.encryption_enabled and self.session_key) else "plaintext"
            if self.encryption_enabled and self.session_key:
                raw = encrypt_message(self.session_key, raw.encode("utf-8"))
            await self.websocket.send_text(raw)
            _LOGGER.info(
                "send_direct: SENT channel=%s type=%s enc=%s",
                self.channel_id, data.get("type", "?"), enc_state,
            )
            return True
        except Exception as e:
            _LOGGER.warning("send_direct: FAILED channel=%s type=%s error=%s", self.channel_id, data.get("type", "?"), e)
            return False

    async def shutdown(self) -> None:
        if self._sender_task and not self._sender_task.done():
            if self._send_queue:
                self._send_queue.put_nowait(None)
            self._sender_task.cancel()
            try:
                await asyncio.wait_for(self._sender_task, timeout=2.0)
            except (asyncio.TimeoutError, asyncio.CancelledError):
                pass
        _LOGGER.debug("shutdown: sender task stopped channel=%s", self.channel_id)


class ModuleHandle:
    """Server-side handle for a registered module (transport layer).

    Created by PushCore.register_module(). Idempotent by name —
    calling register_module("chat") twice returns the same handle.
    """

    def __init__(self, core: "PushCore", module_id: str, name: str) -> None:
        self._core = core
        self.module_id = module_id
        self.name = name

    def send_to_channel(
        self,
        payload: Any,
        to_channel: str,
        src_channel_id: str = "",
    ) -> bool:
        """Send a module message to a target channel (fire-and-forget)."""
        frame = {
            "type": "module_msg",
            "moduleId": self.module_id,
            "payload": payload,
            "ts": time.time(),
            "srcChannelId": src_channel_id,
            "targetChannelId": to_channel,
        }
        _LOGGER.info(
            "ModuleHandle.send_to_channel: module=%s(%s) → channel=%s",
            self.name, self.module_id[:8], to_channel[:12],
        )
        return self._core.send_msg(frame)

    def broadcast(self, payload: Any, src_channel_id: str = "") -> bool:
        """Broadcast a module message to all online channels (fire-and-forget)."""
        frame = {
            "type": "module_msg",
            "moduleId": self.module_id,
            "payload": payload,
            "ts": time.time(),
            "srcChannelId": src_channel_id,
            "targetChannelId": None,
        }
        _LOGGER.info(
            "broadcast: module=%s(%s) → ALL",
            self.name, self.module_id[:8],
        )
        return self._core.broadcast(frame)


class PushCore:
    """Transport-layer singleton: manages channel→WebSocket connections (1:1).

    PUSH = online-only. No offline buffering.

    Preserved from v2:
      - Per-connection asyncio.Queue for outbound messages
      - Fire-and-forget enqueue via call_soon_threadsafe (no blocking)
      - Background sender tasks drain queues and write to WebSockets
      - No threading.Lock on send path

    New in v3:
      - Unified protocol frame: {type, moduleId, payload, ts, srcChannelId, targetChannelId}
      - Idempotent module registration by name
      - Heartbeat uses new frame format (type="ping")
    """

    _instance: Optional["PushCore"] = None
    _lock = threading.Lock()

    @classmethod
    def instance(cls) -> "PushCore":
        with cls._lock:
            if cls._instance is None:
                cls._instance = cls()
                _LOGGER.info("PushCore singleton created")
        return cls._instance

    def __init__(self) -> None:
        self._connections: dict[str, PushConnection] = {}
        self._data_lock = threading.Lock()
        self._loop: Optional[asyncio.AbstractEventLoop] = None

        # Module registry: name → ModuleHandle (idempotent by name)
        self._modules: dict[str, ModuleHandle] = {}

        self._heartbeat_task: Optional[asyncio.Task] = None
        self._heartbeat_interval: float = 60.0
        self._heartbeat_timeout: float = 120.0

    def set_loop(self, loop: asyncio.AbstractEventLoop) -> None:
        old_loop = self._loop
        self._loop = loop
        if old_loop is None:
            _LOGGER.info("set_loop: event loop stored (first connection)")
            self._start_heartbeat(loop)
        else:
            _LOGGER.debug("set_loop: event loop updated (reconnect)")

    def _start_heartbeat(self, loop: asyncio.AbstractEventLoop) -> None:
        if self._heartbeat_task is None or self._heartbeat_task.done():
            self._heartbeat_task = loop.create_task(self._heartbeat_loop())
            _LOGGER.info(
                "heartbeat: started (interval=%ss, timeout=%ss)",
                self._heartbeat_interval, self._heartbeat_timeout,
            )

    async def _heartbeat_loop(self) -> None:
        try:
            while True:
                await asyncio.sleep(self._heartbeat_interval)
                now = time.time()
                conns = self.get_all_connections()
                _LOGGER.info("heartbeat: checking %d channels", len(conns))

                stale: list[PushConnection] = []
                for conn in conns:
                    if conn.channel_id is None:
                        continue
                    age = now - conn.last_pong
                    if age > self._heartbeat_timeout:
                        stale.append(conn)
                    else:
                        ping_frame = {
                            "type": "ping",
                            "ts": now,
                        }
                        if conn._send_queue is not None:
                            conn._send_queue.put_nowait(ping_frame)
                            _LOGGER.debug(
                                "heartbeat: ping sent channel=%s last_pong_age=%.1fs",
                                conn.channel_id, age,
                            )

                for conn in stale:
                    age = now - conn.last_pong
                    _LOGGER.warning(
                        "heartbeat: STALE channel=%s (no pong for %.0fs) — removing",
                        conn.channel_id, age,
                    )
                    await conn.shutdown()
                    self.unregister(conn)
                    from st_push.user_channel_manage import UserChannelManage
                    ucm = UserChannelManage.instance()
                    if conn.channel_id:
                        ucm.cleanup_stale(conn.channel_id)

        except asyncio.CancelledError:
            _LOGGER.info("heartbeat: task cancelled")
        except Exception as e:
            _LOGGER.warning("heartbeat: unexpected error: %s", e)

    def get_loop(self) -> Optional[asyncio.AbstractEventLoop]:
        return self._loop

    def register_channel(self, conn: PushConnection, channel_id: str) -> None:
        """Register a connection under a channel_id (1:1).

        If the channel_id already has a different connection, the old one
        is shut down (replaced).
        """
        with self._data_lock:
            old = self._connections.get(channel_id)
            if old and old is not conn:
                _LOGGER.info("register_channel: REPLACING old connection for channel=%s", channel_id)
                if self._loop:
                    asyncio.run_coroutine_threadsafe(old.shutdown(), self._loop)

            conn.channel_id = channel_id
            self._connections[channel_id] = conn
            online_channels = len(self._connections)
        _LOGGER.info(
            "register_channel: channel=%s online_channels=%d",
            channel_id, online_channels,
        )

    def unregister(self, conn: PushConnection) -> None:
        with self._data_lock:
            if conn.channel_id and self._connections.get(conn.channel_id) is conn:
                self._connections.pop(conn.channel_id, None)
                online_count = len(self._connections)
                _LOGGER.info(
                    "unregister: channel=%s removed, online_channels=%d",
                    conn.channel_id, online_count,
                )
            else:
                _LOGGER.debug(
                    "unregister: conn for channel=%s not current (already replaced)",
                    conn.channel_id,
                )

    def get_channels(self) -> list[str]:
        with self._data_lock:
            return list(self._connections.keys())

    def is_online(self, channel_id: str) -> bool:
        with self._data_lock:
            return channel_id in self._connections

    def get_connection(self, channel_id: str) -> Optional[PushConnection]:
        with self._data_lock:
            return self._connections.get(channel_id)

    def get_all_connections(self) -> list[PushConnection]:
        with self._data_lock:
            return list(self._connections.values())

    # ------------------------------------------------------------------
    # Module registration (idempotent by name)
    # ------------------------------------------------------------------

    def register_module(self, name: str) -> ModuleHandle:
        """Register a module by name. Idempotent — same name returns same handle."""
        with self._data_lock:
            # Check if module with this name already exists
            existing = self._modules.get(name)
            if existing is not None:
                _LOGGER.info(
                    "register_module: REUSING existing module name=%s module_id=%s",
                    name, existing.module_id[:8],
                )
                return existing

            # First registration — allocate new UUID
            module_id = str(uuid.uuid4())
            handle = ModuleHandle(self, module_id, name)
            self._modules[name] = handle
            module_count = len(self._modules)
        _LOGGER.info(
            "register_module: NEW module name=%s module_id=%s total_modules=%d",
            name, module_id, module_count,
        )
        return handle

    def get_module(self, name: str) -> Optional[ModuleHandle]:
        with self._data_lock:
            return self._modules.get(name)

    def get_modules(self) -> list[ModuleHandle]:
        with self._data_lock:
            return list(self._modules.values())

    # ------------------------------------------------------------------
    # Message delivery (fire-and-forget via queue)
    # ------------------------------------------------------------------

    def send_msg(self, frame: dict) -> bool:
        """Enqueue a message frame to the target channel's send queue.

        The frame must contain targetChannelId. Returns True if the channel
        is online and message was enqueued, False if offline.
        """
        if self._loop is None:
            _LOGGER.warning(
                "send_msg: event loop NOT SET → target=%s",
                frame.get("targetChannelId", "?"),
            )
            return False

        target_channel = frame.get("targetChannelId")
        if not target_channel:
            _LOGGER.warning("send_msg: no targetChannelId in frame type=%s", frame.get("type"))
            return False

        conn = self.get_connection(target_channel)
        if conn is not None and conn._send_queue is not None:
            _LOGGER.info(
                "send_msg: → channel=%s (online, enqueuing) type=%s moduleId=%s",
                target_channel[:12], frame.get("type", "?"),
                (frame.get("moduleId") or "-")[:8] if frame.get("moduleId") else "-",
            )
            return conn.enqueue(frame, self._loop)

        _LOGGER.info(
            "send_msg: → channel=%s (OFFLINE, returning False) type=%s",
            target_channel[:12], frame.get("type", "?"),
        )
        return False

    def broadcast(self, frame: dict) -> bool:
        """Broadcast a frame to all online channels (fire-and-forget).

        Returns True if at least one channel's queue accepted the message.
        """
        if self._loop is None:
            _LOGGER.warning("broadcast: event loop NOT SET")
            return False

        conns = self.get_all_connections()
        _LOGGER.info(
            "broadcast: type=%s moduleId=%s → %d online channels",
            frame.get("type", "?"),
            (frame.get("moduleId") or "-")[:8] if frame.get("moduleId") else "-",
            len(conns),
        )

        if not conns:
            _LOGGER.warning("broadcast: no online channels — message dropped")
            return False

        success = False
        for conn in conns:
            if conn._send_queue is not None:
                if conn.enqueue(frame, self._loop):
                    success = True
        return success
