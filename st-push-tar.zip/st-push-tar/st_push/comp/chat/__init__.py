"""
st_push.comp.chat — Chat component for Streamlit (v3.0).

Optional UI component bundled with st_push. Receives a shared PushClient
(created once at app level) instead of creating its own.

Architecture:
  - st_push provides the WebSocket transport + module routing (channel-based)
  - st_push.comp.chat receives a shared PushClient, registers a "chat" module
  - Messages arrive via st_push's frontend dispatch system
  - Frontend handles display + input, sends outgoing messages via setComponentValue
  - Multi-device sync: send() delivers to recipient AND echoes to sender's channels

Usage:
    from st_push import PushClient
    from st_push.comp.chat import ChatClient

    push_client = PushClient.session_instance(user="alice")
    chat = ChatClient(push_client, user_name="alice")
    chat.render(peer="bob")  # renders chat window

    # Send a message to another user
    chat.send("Hello Bob!", to_user="bob")
"""
from __future__ import annotations

import os
import time
from dataclasses import dataclass
from typing import Any, Optional

import streamlit as st
import streamlit.components.v1 as components
from streamlit.logger import get_logger

from st_push import PushClient, Module

_LOGGER = get_logger(__name__)

parent_dir = os.path.dirname(os.path.abspath(__file__))
build_dir = os.path.join(parent_dir, "frontend", "build")
_component_func = None


def _get_component_func():
    global _component_func
    if _component_func is None:
        _component_func = components.declare_component("st_chat", path=build_dir)
    return _component_func


@dataclass
class ChatMessage:
    from_user: str
    to_user: str
    content: str
    ts: float = 0.0

    def to_dict(self) -> dict:
        return {
            "fromUser": self.from_user,
            "toUser": self.to_user,
            "content": self.content,
            "ts": self.ts or time.time(),
        }


class ChatClient:
    """In-app chat client with a chat window UI (v3.0).

    Receives a shared PushClient (created once at app level) instead of
    creating its own. The PushClient is public infrastructure shared by
    all components in the session.

    If the PushClient has no bound user, ChatClient binds it to
    user_name on init. If it already has a (possibly different) user,
    rebinds to user_name.

    Multi-device sync: send() delivers to the recipient's channels AND
    echoes to the sender's own channels. The frontend dedups by
    (fromUser, toUser, content, ts) to avoid duplicate display on the
    originating channel.

    Parameters
    ----------
    push_client : PushClient
        Shared session-level push client (public infrastructure).
    user_name : str
        Business-layer user identity (e.g., "alice"). Used in chat payload
        for display and routing by the recipient.
    key : str
        Streamlit component key suffix (for session_state isolation).
    """

    def __init__(
        self,
        push_client: "PushClient",
        user_name: str,
        key: str = "st_chat",
    ) -> None:
        self._client = push_client
        self.user_name = user_name
        self._key = key

        # Ensure PushClient has the right user bound
        if self._client.get_user() != user_name:
            self._client.bind_user(user_name)

        # Register chat module (idempotent by name — PushCore deduplicates)
        self._module: Module = self._client.register_module("chat")

        _LOGGER.info(
            "ChatClient: initialized user=%s channel=%s module_id=%s",
            user_name, self._client.channel_id[:12], self._module.module_id[:8],
        )

    @property
    def module_id(self) -> str:
        return self._module.module_id

    @property
    def channel_id(self) -> str:
        return self._client.channel_id

    def render(self, peer: str = "") -> Any:
        """Render the chat window component.

        Passes the module ID and channel info to the frontend. The frontend
        registers a callback via window.parent.st_push.register(moduleId, callback)
        to receive incoming chat messages.

        Parameters
        ----------
        peer : str
            Default peer to chat with (optional, frontend can change).

        Returns
        -------
        dict or None
            The latest outgoing message (fromUser, toUser, content), or None.
        """
        return _get_component_func()(
            moduleUuid=self._module.module_id,
            channelId=self._client.channel_id,
            userName=self.user_name,
            peer=peer,
            key=self._key,
            default=None,
        )

    def send(self, content: str, to_user: str) -> bool:
        """Send a chat message to a specific user (v3.0).

        Delivers to the recipient's channels (multi-device) AND echoes to
        the sender's own channels (multi-device sync). The frontend dedups
        on the originating channel.

        PUSH = online-only. If the recipient is offline, returns False
        (but still echoes to sender's own channels).
        """
        msg = ChatMessage(
            from_user=self.user_name,
            to_user=to_user,
            content=content,
        )
        payload = msg.to_dict()
        _LOGGER.info(
            "send: from=%s → user=%s content=\"%s\"",
            self.user_name, to_user, content[:50],
        )

        # 1. Deliver to recipient's channels (multi-device)
        delivered = self._module.send_msg(payload, target_user=to_user)

        # 2. Echo to sender's own channels (multi-device sync)
        #    target_user=None → sends to all of sender's channels (including self).
        #    Frontend dedups by (fromUser, toUser, content, ts) to avoid
        #    duplicate display on the originating channel.
        self._module.send_msg(payload)

        return delivered


__all__ = ["ChatClient", "ChatMessage"]
