# st_chat — 聊天组件（v3.0）

> 依赖 `st_push` 的推送通道和模块注册系统。方案设计见 `prd_st_push_2.md`。

## 简介

独立的聊天窗口 UI 组件。接收应用层注入的 `PushClient`（公共基础设施），
注册 "chat" 模块，渲染聊天窗口，消息经加密 WebSocket 实时收发。

支持多端登录和多端同步：
- **多端登录**：一个 user 可有多个 channel（多标签/多设备），消息推送到所有 channel
- **多端发送同步**：发送消息时，不仅投递给接收者，还 echo 给发送者的所有 channel（不排除发起方 channel，前端按 fromUser+toUser+content+ts 去重）

## 用法

```python
from st_push import PushClient
from st_chat import ChatClient

# 应用层创建公共 PushClient（session 单例，一个会话一个 WS 连接）
push_client = PushClient.session_instance(user="alice")

# 注入给聊天组件
chat = ChatClient(push_client, user_name="alice")
outgoing = chat.render(peer="bob")  # 渲染聊天窗口

if outgoing and outgoing.get("action") == "send":
    chat.send(outgoing["content"], to_user=outgoing["toUser"])
```

## 运行演示

```bash
python demos/chat_app.py
```

## API

| 方法 | 说明 |
|------|------|
| `ChatClient(push_client, user_name, key="st_chat")` | 创建聊天客户端，注入公共 PushClient，自动注册 "chat" 模块 |
| `render(peer="") -> dict \| None` | 渲染聊天窗口，返回 outgoing 消息 |
| `send(content, to_user) -> bool` | 发送聊天消息（含多端发送同步） |
| `module_id -> str` | 只读属性，模块 ID |
| `channel_id -> str` | 只读属性，复用 PushClient 的 channel ID |

### ChatMessage

| 字段 | 说明 |
|------|------|
| `from_user` | 发送者 |
| `to_user` | 接收者 |
| `content` | 消息内容 |
| `ts` | 时间戳 |

## send() 多端同步流程

`ChatClient.send(content, to_user)` 执行两个操作：

1. **投递给接收者**：`module.send_msg(payload, target_user=to_user)`，经 UserChannelManage 解析 `to_user→[channel_id]`，投递到接收者的所有 channel
2. **echo 给发送者所有 channel**：`module.send_msg(payload)`（target_user=None），投递到发送者的所有 channel（含发起方）。前端按 (fromUser, toUser, content, ts) 去重，避免重复显示

```
alice(channel_A) 发消息给 bob
  ├─ → bob 的所有 channel（接收同步）
  └─ → alice 的所有 channel（含 channel_A）（发送同步）
       前端按 fromUser+toUser+content+ts 去重
```

## 架构

- `st_push` 传输层：WebSocket 传输 + 模块路由（channel-based），PushCore 不知 user
- `st_push` 业务层：UserChannelManage 解析 `user→[channel_id]`，仅服务 PushClient
- `st_push` 接入层：PushClient（session 单例）+ Module，由应用层创建注入
- `st_chat` 接收注入的 PushClient，注册 "chat" 模块，渲染聊天窗口 UI
- 消息通过 `st_push` 前端分发系统到达聊天 callback
- 前端处理显示 + 输入，通过 `setComponentValue` 回传 Python 触发 `send()`

## 文件

| 文件 | 说明 |
|------|------|
| `__init__.py` | ChatClient + ChatMessage |
| `frontend/build/index.html` | 聊天窗口 UI |
