"""
st_push.comp — Optional UI components bundled with st_push.

Sub-packages:
  - st_push.comp.chat   : ChatClient — chat window UI
  - st_push.comp.notify : NotificationClient — bell icon + modal popup

These are optional components. st_push itself has no hard dependency on them.
Import on demand:

    from st_push.comp.chat import ChatClient
    from st_push.comp.notify import NotificationClient
"""
