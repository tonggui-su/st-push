"""
st_push.comp.notify — Notification component for Streamlit (v3.0).

Optional UI component bundled with st_push. Receives a shared PushClient
(created once at app level) instead of creating its own.

Architecture:
  - st_push provides the WebSocket transport + module routing (channel-based)
  - st_push.comp.notify receives a shared PushClient, registers a "notify" module
  - Messages arrive via st_push's frontend dispatch system
  - Frontend injects a bell icon + modal into the parent DOM
  - User must click the bell to see notifications; must click each to mark read
  - Each notification may carry an action button (label + payload). Clicking the
    button triggers the on_click callback registered via NotificationClient.render().

Usage:
    from st_push import PushClient
    from st_push.comp.notify import NotificationClient

    push_client = PushClient.session_instance(user="alice")
    notifier = NotificationClient(push_client, user_name="alice")
    notifier.send_notification(
        to_user="bob",
        title="New Task",
        body="Fix the login bug",
        level="info",
        action="查看任务",
        payload={"task_id": 123, "url": "/task/123"},
    )

    # On render, pass a callback that receives the payload when the
    # notification's action button is clicked.
    def handle_click(payload):
        st.toast(f"Clicked: {payload}")
        # e.g. st.query_params["task_id"] = payload["task_id"]

    notifier.render(on_click=handle_click)
"""
from __future__ import annotations

import os
import time
from dataclasses import dataclass
from typing import Any, Callable, Literal, Optional

import streamlit as st
import streamlit.components.v1 as components
from streamlit.logger import get_logger

from st_push import PushClient, Module

_LOGGER = get_logger(__name__)

parent_dir = os.path.dirname(os.path.abspath(__file__))
build_dir = os.path.join(parent_dir, "frontend", "build")
_component_func = None


def _get_component_func():
    global _component_func
    if _component_func is None:
        _component_func = components.declare_component("st_notify", path=build_dir)
    return _component_func


@dataclass
class NotificationPayload:
    title: str
    body: str = ""
    level: Literal["info", "warning", "error", "success"] = "info"
    action: Optional[str] = None
    payload: Optional[Any] = None
    ts: float = 0.0

    def to_dict(self) -> dict:
        return {
            "title": self.title,
            "body": self.body,
            "level": self.level,
            "action": self.action,
            "payload": self.payload,
            "ts": self.ts or time.time(),
        }


class NotificationClient:
    """In-app notification client with bell icon + modal popup (v3.0).

    Receives a shared PushClient (created once at app level) instead of
    creating its own. The PushClient is public infrastructure shared by
    all components in the session.

    If the PushClient has no bound user, NotificationClient binds it to
    user_name on init. If it already has a (possibly different) user,
    rebinds to user_name.

    Parameters
    ----------
    push_client : PushClient
        Shared session-level push client (public infrastructure).
    user_name : str
        The user identity to bind to the push channel.
    key : str
        Streamlit component key suffix (for session_state isolation).
    """

    def __init__(
        self,
        push_client: "PushClient",
        user_name: str,
        key: str = "st_notify",
    ) -> None:
        self._client = push_client
        self.user_name = user_name
        self._key = key

        # Ensure PushClient has the right user bound
        if self._client.get_user() != user_name:
            self._client.bind_user(user_name)

        # Register notify module (idempotent by name)
        self._module: Module = self._client.register_module("notify")

        _LOGGER.info(
            "NotificationClient: initialized user=%s channel=%s module_id=%s",
            user_name, self._client.channel_id, self._module.module_id[:8],
        )

    @property
    def module_id(self) -> str:
        return self._module.module_id

    @property
    def channel_id(self) -> str:
        return self._client.channel_id

    def render(
        self,
        on_click: Optional[Callable[[Any], None]] = None,
    ) -> bool:
        """Render the notification bell icon component.

        Passes the module ID to the frontend so it can register a callback
        via window.parent.st_push.register(moduleId, callback). The frontend
        injects a bell icon + modal into the parent DOM.

        Parameters
        ----------
        on_click : callable | None
            Callback invoked when a notification's action button is clicked.
            Receives the ``payload`` field from the clicked notification.
            Called once per click (deduplicated across reruns via a
            session_state event-id tracker).

        Returns
        -------
        bool
            True if an action-button click was dispatched this rerun,
            False otherwise.
        """
        component_value = _get_component_func()(
            moduleUuid=self._module.module_id,
            key=self._key,
            default=None,
        )

        clicked = False
        if (
            component_value
            and isinstance(component_value, dict)
            and component_value.get("action") == "click"
        ):
            # Dedup across reruns: each click carries a notificationId that
            # is unique per frontend session. Only fire the callback for
            # an id we haven't seen before.
            notif_id = component_value.get("notificationId")
            seen_key = f"{self._key}_seen_click"
            if seen_key not in st.session_state:
                st.session_state[seen_key] = set()
            if notif_id not in st.session_state[seen_key]:
                st.session_state[seen_key].add(notif_id)
                payload = component_value.get("payload")
                _LOGGER.info(
                    "notify on_click fired: label=%s payload=%s",
                    component_value.get("actionLabel"), payload,
                )
                if on_click is not None:
                    on_click(payload)
                clicked = True

        return clicked

    def send_notification(
        self,
        to_user: str,
        title: str,
        body: str = "",
        level: Literal["info", "warning", "error", "success"] = "info",
        action: Optional[str] = None,
        payload: Optional[Any] = None,
        from_user: str = "SYSTEM",
    ) -> bool:
        """Send a notification to a specific user.

        Resolves to_user → [channel_id] via UserChannelManage. If the user
        is offline, returns False (PUSH = online-only).

        Parameters
        ----------
        action : str | None
            Button label. If set, frontend shows a button with this text.
        payload : Any | None
            Data passed to the on_click callback when the button is clicked.
            Can be any JSON-serializable value (dict, str, number, etc.).
        """
        p = NotificationPayload(
            title=title, body=body, level=level,
            action=action, payload=payload,
        )
        _LOGGER.info(
            "send_notification: title=\"%s\" level=%s → user=%s from=%s",
            title, level, to_user, from_user,
        )
        return self._module.send_msg(p.to_dict(), target_user=to_user)

    def broadcast_alert(
        self,
        title: str,
        body: str = "",
        level: Literal["info", "warning", "error", "success"] = "warning",
        from_user: str = "SYSTEM",
    ) -> bool:
        """Broadcast an alert to all online channels across all users."""
        payload = NotificationPayload(title=title, body=body, level=level)
        _LOGGER.info(
            "broadcast_alert: title=\"%s\" level=%s → ALL from=%s",
            title, level, from_user,
        )
        return self._module.broadcast_msg(payload.to_dict())

    def is_online(self, user: str) -> bool:
        """Check if a user has at least one online channel."""
        return self._client.is_online(user)


__all__ = ["NotificationClient", "NotificationPayload"]
