"""
UserChannelManage — Business-layer mapping: user → [channel_id] (1:N).

Services PushClient internally. Not exposed to end users directly.

Responsibilities:
  - Map user names to their active channel IDs (multi-device: 1:N)
  - Provide channel lookup for message routing
  - Track online status per user
  - Clean up stale channels (called by PushCore heartbeat)

Channel lifecycle management is internal — PushCore calls cleanup_stale()
when a heartbeat detects a dead connection.
"""
from __future__ import annotations

import threading
from typing import Optional

from streamlit.logger import get_logger

from st_push.push_core import PushCore

_LOGGER = get_logger(__name__)


class UserChannelManage:
    """Maps user names to their active channel IDs (1:N).

    Thread-safe: uses a lightweight lock for bind/unbind (infrequent).
    """

    _instance: Optional["UserChannelManage"] = None
    _lock = threading.Lock()

    @classmethod
    def instance(cls) -> "UserChannelManage":
        with cls._lock:
            if cls._instance is None:
                cls._instance = cls()
                _LOGGER.info("UserChannelManage singleton created")
        return cls._instance

    def __init__(self) -> None:
        self._user_channels: dict[str, set[str]] = {}
        self._channel_user: dict[str, str] = {}
        self._data_lock = threading.Lock()

    def bind(self, user: str, channel_id: str) -> None:
        """Associate a channel with a user (multi-device friendly).

        A user can have multiple channels. A channel can only belong to
        one user. If the channel was previously bound to a different user,
        it is removed from the old user's set first.
        """
        with self._data_lock:
            old_user = self._channel_user.get(channel_id)
            if old_user and old_user != user:
                old_set = self._user_channels.get(old_user)
                if old_set:
                    old_set.discard(channel_id)
                    if not old_set:
                        self._user_channels.pop(old_user, None)
                _LOGGER.info(
                    "bind: channel=%s switching user %s → %s",
                    channel_id[:12], old_user, user,
                )

            if user not in self._user_channels:
                self._user_channels[user] = set()
            self._user_channels[user].add(channel_id)
            self._channel_user[channel_id] = user

            ch_count = len(self._user_channels[user])
        _LOGGER.info(
            "bind: user=%s channel=%s total_channels_for_user=%d",
            user, channel_id[:12], ch_count,
        )

    def unbind(self, channel_id: str) -> None:
        """Remove a channel from its user's set."""
        with self._data_lock:
            user = self._channel_user.pop(channel_id, None)
            if user:
                ch_set = self._user_channels.get(user)
                if ch_set:
                    ch_set.discard(channel_id)
                    if not ch_set:
                        self._user_channels.pop(user, None)
                _LOGGER.info(
                    "unbind: channel=%s removed from user=%s",
                    channel_id[:12], user,
                )

    def get_channels(self, user: str) -> list[str]:
        """Get all active channel IDs for a user."""
        with self._data_lock:
            ch_set = self._user_channels.get(user)
            if ch_set:
                return list(ch_set)
            return []

    def is_online(self, user: str) -> bool:
        """Check if a user has at least one active channel in the core."""
        with self._data_lock:
            ch_set = self._user_channels.get(user)
            if not ch_set:
                return False
        # Check core for actual online status (outside lock)
        core = PushCore.instance()
        for ch_id in list(ch_set):
            if core.is_online(ch_id):
                return True
        return False

    def get_users(self) -> list[str]:
        with self._data_lock:
            return list(self._user_channels.keys())

    def get_user_for_channel(self, channel_id: str) -> Optional[str]:
        with self._data_lock:
            return self._channel_user.get(channel_id)

    def cleanup_stale(self, channel_id: str) -> None:
        """Remove a stale channel from its user's set.

        Called by PushCore heartbeat when a connection is removed.
        """
        self.unbind(channel_id)


def generate_channel_id() -> str:
    """Generate a unique channel ID."""
    import uuid
    return "ch-" + uuid.uuid4().hex[:16]
