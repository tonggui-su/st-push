"""
st_push 2.0 — Transport + Access layer for real-time push in Streamlit.

Architecture:
  - Transport layer (push_core.py + routes.py + crypto.py):
    channel → conn (1:1), message queues, encryption, heartbeat.
    Knows nothing about "user".
  - Business layer (user_channel_manage.py):
    user → [channel_id] (1:N). Maps users to their active channels.
    Services PushClient internally, not exposed to end users.
  - Access layer (this file):
    PushClient (per-session) + Module (per-module). The main API surface.

Usage:
    from st_push import PushClient

    client = PushClient(user="alice")  # generates channel_id, binds user, renders
    module = client.register_module("chat")
    module.send_msg({"text": "hello"}, target_user="bob")
    module.broadcast_msg({"alert": "restart"})

Startup (requires route mounting):
    python demos/chat_app.py
"""
import os
import time
from typing import Any, Optional

import streamlit as st
import streamlit.components.v1 as components
from streamlit.logger import get_logger

from st_push.push_core import PushCore, ModuleHandle
from st_push.routes import create_push_routes
from st_push.user_channel_manage import UserChannelManage, generate_channel_id

_LOGGER = get_logger(__name__)

parent_dir = os.path.dirname(os.path.abspath(__file__))
build_dir = os.path.join(parent_dir, "frontend", "build")

_component_func = None


def _get_component_func():
    """Lazily initialize the Streamlit custom component."""
    global _component_func
    if _component_func is None:
        _component_func = components.declare_component("st_push", path=build_dir)
    return _component_func


class Module:
    """Business-layer module handle. Created by PushClient.register_module().

    Holds a reference to its PushClient and delegates send/broadcast
    operations to it. The caller never needs to handle module_id directly.
    """

    def __init__(self, client: "PushClient", module_id: str, name: str) -> None:
        self._client = client
        self.module_id = module_id
        self.name = name

    def send_msg(self, payload: Any, target_user: Optional[str] = None) -> bool:
        """Send a module message to a target user (fire-and-forget).

        Delegates to PushClient.send_msg(). If target_user is None:
        - If client has a bound user, sends to all that user's channels
        - Otherwise sends to self channel only
        """
        return self._client.send_msg(self, payload, target_user)

    def broadcast_msg(self, payload: Any) -> bool:
        """Broadcast a module message to all online channels (fire-and-forget)."""
        return self._client.broadcast_msg(self, payload)


class PushClient:
    """Per-session push client. The main API surface for st_push.

    Session singleton: use PushClient.session_instance(user=...) to obtain the
    shared instance. Multiple components (st_chat, st_notify, etc.) share
    the same PushClient — one WebSocket connection per session.

    On init:
      1. Generates a unique channel_id (stored in session_state)
      2. Optionally binds to a user (via UserChannelManage)
      3. Renders the invisible WS transport component (connect())

    The channel_id is stored in session_state to survive reruns.
    """

    _SESSION_KEY = "_st_push_client_singleton"

    @classmethod
    def session_instance(
        cls,
        user: Optional[str] = None,
        key: str = "st_push_client",
    ) -> "PushClient":
        """Get the session-level singleton PushClient, creating it if absent.

        If `user` is provided and the existing instance has no user bound,
        binds it. If `user` differs from the existing bound user, rebinds.
        """
        inst = st.session_state.get(cls._SESSION_KEY)
        if inst is not None:
            # Reuse existing instance
            if user and inst.get_user() != user:
                inst.bind_user(user)
            # Re-render on every rerun (Streamlit requires it)
            inst.connect()
            return inst

        # First creation in this session
        inst = cls(user=user, key=key)
        st.session_state[cls._SESSION_KEY] = inst
        return inst

    def __init__(self, user: Optional[str] = None, key: str = "st_push_client") -> None:
        self._core = PushCore.instance()
        self._ucm = UserChannelManage.instance()
        self._key = key

        # Generate or recover channel_id from session_state
        ss_key = f"{key}_channel_id"
        if ss_key not in st.session_state:
            st.session_state[ss_key] = generate_channel_id()
        self.channel_id = st.session_state[ss_key]

        # Bind user if provided
        self.user: Optional[str] = None
        if user:
            self.bind_user(user)

        # Render the invisible WS transport component immediately
        self._render_result = self.connect()

        _LOGGER.info(
            "PushClient: initialized channel=%s user=%s",
            self.channel_id[:12], self.user or "(none)",
        )

    def bind_user(self, user: str) -> None:
        """Bind or rebind this client's channel to a user."""
        self.user = user
        self._ucm.bind(user=user, channel_id=self.channel_id)
        # Persist user in query_params for cross-refresh recovery
        st.query_params["st_push_user"] = user
        _LOGGER.info("PushClient.bind_user: user=%s channel=%s", user, self.channel_id[:12])

    def get_user(self) -> Optional[str]:
        """Return the user currently bound to this client, if any."""
        return self.user

    def connect(self) -> Any:
        """Render the invisible push transport component.

        Establishes the WebSocket connection between the frontend
        component iframe and /st_push/ws.
        """
        _LOGGER.debug(
            "PushClient.connect: rendering transport component for channel=%s",
            self.channel_id[:12],
        )
        return _get_component_func()(
            channelId=self.channel_id,
            key=f"st_push_{self.channel_id}",
            default=None,
        )

    def register_module(self, name: str) -> Module:
        """Register a module and return a Module handle.

        Idempotent within a session: calling with the same name returns
        the same Module object. PushCore also deduplicates by name
        globally, so the module_id is stable across reruns.
        """
        # Session-level cache
        modules_key = f"{self._key}_modules"
        if modules_key not in st.session_state:
            st.session_state[modules_key] = {}

        if name in st.session_state[modules_key]:
            existing = st.session_state[modules_key][name]
            _LOGGER.info(
                "register_module: REUSING session module name=%s module_id=%s",
                name, existing.module_id[:8],
            )
            return existing

        # First registration — PushCore.register_module is idempotent by name
        handle = self._core.register_module(name)
        module = Module(self, handle.module_id, name)
        st.session_state[modules_key][name] = module
        _LOGGER.info(
            "register_module: NEW session module name=%s module_id=%s",
            name, module.module_id[:8],
        )
        return module

    def send_msg(
        self,
        module: Module,
        payload: Any,
        target_user: Optional[str] = None,
    ) -> bool:
        """Send a module message to a target user (fire-and-forget).

        - target_user specified: resolve via UserChannelManage to [channel_id],
          multiple channels → multiple frames (one per channel).
        - target_user None + client has bound user: send to all that user's channels.
        - target_user None + no bound user: send to self channel only.

        Does NOT exclude src_channelId — all target channels receive the message.
        """
        ts = time.time()
        src_channel = self.channel_id

        # Resolve target channels
        if target_user is not None:
            target_channels = self._ucm.get_channels(target_user)
            if not target_channels:
                _LOGGER.info(
                    "send_msg: target_user=%s OFFLINE (no channels)",
                    target_user,
                )
                return False
        elif self.user is not None:
            # Send to all of this user's own channels (including self)
            target_channels = self._ucm.get_channels(self.user)
            if not target_channels:
                target_channels = [src_channel]
        else:
            # No user bound — send to self only
            target_channels = [src_channel]

        _LOGGER.info(
            "send_msg: module=%s(%s) payload → %d channel(s) target_user=%s",
            module.name, module.module_id[:8],
            len(target_channels), target_user or "(self)",
        )

        success = False
        for ch_id in target_channels:
            frame = {
                "type": "module_msg",
                "moduleId": module.module_id,
                "payload": payload,
                "ts": ts,
                "srcChannelId": src_channel,
                "targetChannelId": ch_id,
            }
            if self._core.send_msg(frame):
                success = True

        return success

    def broadcast_msg(self, module: Module, payload: Any) -> bool:
        """Broadcast a module message to all online channels (fire-and-forget)."""
        frame = {
            "type": "module_msg",
            "moduleId": module.module_id,
            "payload": payload,
            "ts": time.time(),
            "srcChannelId": self.channel_id,
            "targetChannelId": None,
        }
        return self._core.broadcast(frame)

    def is_online(self, user: str) -> bool:
        """Check if a user has at least one online channel."""
        return self._ucm.is_online(user)


def register(name: str) -> Module:
    """Convenience function: register a module using the session singleton PushClient.

    Creates or reuses the session-level PushClient, then registers the
    module. Useful for components that don't manage their own PushClient.
    """
    client = PushClient.session_instance()
    return client.register_module(name)


__all__ = [
    "PushClient",
    "Module",
    "PushCore",
    "ModuleHandle",
    "UserChannelManage",
    "generate_channel_id",
    "register",
    "create_push_routes",
]
