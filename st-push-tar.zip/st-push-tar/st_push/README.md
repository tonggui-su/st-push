# st_push — WebSocket 路由 + 模块系统 + 加密（v3.0）

> 方案设计见 `spec/prd_st_push_2.md`。踩坑记录见 `spec/change.md`。

## 简介

WebSocket 路由挂载到 Streamlit 的 Starlette App，真推送，零空闲流量。
每连接 AES-256-GCM 加密，模块注册系统支持多组件共存。

**架构分层**：
- **传输层**（push_core.py / routes.py / crypto.py）：`channel→conn`(1:1) + module 路由，不知 user 为何物
- **业务层**（user_channel_manage.py）：`UserChannelManage` 单例，`user→[channel_id]`(1:N) 多端登录映射，仅服务于 PushClient
- **接入层**（__init__.py）：`PushClient`（每会话）+ `Module`（每模块），对外 API 收口

关键约束：脱离 user-channel 关系，PUSH 也能正常运作。传输层 API 只认 channel。

## v3.0 协议帧

所有消息统一结构：
```json
{ "type", "moduleId", "payload", "ts", "srcChannelId", "targetChannelId" }
```

| type | 方向 | 加密 | 说明 |
|------|------|------|------|
| `register` | C→S | 明文 | 客户端注册，带 `srcChannelId` |
| `ack` | S→C | 明文 | 注册确认，`payload` 含 `sessionKey` + `algo` |
| `ping` | S→C | 加密 | 心跳检测 |
| `pong` | C→S | 加密 | 心跳响应 |
| `error` | S→C | 明文 | 错误信息 |
| `module_msg` | 双向 | 加密 | 模块消息，带 `moduleId` + `payload` |

## 用法

### 启动器（挂载路由）

```python
# app.py
from streamlit.web.server.starlette import App
import st_push

app = App("script.py", routes=st_push.create_push_routes())
if __name__ == "__main__":
    app.run()
```

### 脚本

```python
from st_push import PushClient
from st_chat import ChatClient
from st_notify import NotificationClient

# 应用层创建公共 PushClient（session 单例，一个会话一个 WS 连接）
push_client = PushClient.session_instance(user="alice")

# 注入给组件（组件共享同一个 push_client）
chat = ChatClient(push_client, user_name="alice")
notifier = NotificationClient(push_client, user_name="alice")

# 模块注册（幂等，按 name 去重）
module = push_client.register_module("my_module")

# 发送给指定用户（经 UserChannelManage 解析 user→channels）
module.send_msg({"text": "hello"}, target_user="bob")

# 广播给所有在线 channel
module.broadcast_msg({"alert": "restart"})

# 检查用户在线状态
push_client.is_online("bob")
```

## 运行演示

```bash
python demos/chat_app.py          # 聊天
python demos/notification_app.py  # 通知
```

## API — 接入层

### PushClient

| 方法 | 说明 |
|------|------|
| `PushClient.session_instance(user=None, key=...) -> PushClient` | **推荐**：获取 session 级单例，不存在则创建。多个组件共享同一个 |
| `PushClient(user=None, key=...)` | 直接构造（通常用 session_instance 代替） |
| `bind_user(user)` | 绑定/重绑 user（同步 query_params） |
| `get_user() -> str \| None` | 查询当前绑定的 user |
| `connect() -> Any` | 渲染不可见 WS 传输组件（session_instance 每次 rerun 调用） |
| `register_module(name) -> Module` | 注册模块（幂等，session 级缓存 + PushCore 全局去重） |
| `send_msg(module, payload, target_user=None) -> bool` | 发送模块消息给用户的所有 channel |
| `broadcast_msg(module, payload) -> bool` | 广播给所有在线 channel |
| `is_online(user) -> bool` | 用户是否有在线 channel |

### Module

| 方法 | 说明 |
|------|------|
| `Module.send_msg(payload, target_user=None) -> bool` | 委托 PushClient 发送 |
| `Module.broadcast_msg(payload) -> bool` | 委托 PushClient 广播 |

### register（便捷函数）

| 方法 | 说明 |
|------|------|
| `register(name) -> Module` | 用 session 默认 PushClient 注册模块 |

## API — 传输层（PushCore 单例）

| 方法 | 说明 |
|------|------|
| `PushCore.instance()` | 获取单例 |
| `register_channel(conn, channel_id)` | 注册连接（1:1，旧连接被替换） |
| `unregister(conn)` | 移除连接 |
| `register_module(name) -> ModuleHandle` | 注册模块（幂等，按 name 去重） |
| `send_msg(frame) -> bool` | 入队消息到 targetChannelId（fire-and-forget） |
| `broadcast(frame) -> bool` | 广播给所有在线 channel |
| `is_online(channel_id) -> bool` | 检查 channel 是否在线 |

## API — 业务层（UserChannelManage 单例）

| 方法 | 说明 |
|------|------|
| `UserChannelManage.instance()` | 获取单例 |
| `bind(user, channel_id)` | 绑定 user→channel（多端友好，1:N） |
| `unbind(channel_id)` | 移除 channel 绑定 |
| `get_channels(user) -> list[str]` | 获取 user 的所有 channel |
| `is_online(user) -> bool` | user 是否有在线 channel |
| `get_users() -> list[str]` | 所有已绑定的 user |
| `cleanup_stale(channel_id)` | 心跳清理时移除 channel（PushCore 内部调用） |

## 核心规则

- PUSH = 仅在线推送，离线返回 False，不缓冲
- **PushClient 是公共基础设施**：由应用层创建一次（`session_instance`），注入给组件，一个 session 一个 WS 连接
- 传输层不知 user：PushCore 只认 channel
- 业务层仅服务 PushClient：UserChannelManage 不对外暴露
- 多端登录：一个 user 可有多个 channel（1:N），一个 channel 只属于一个 user
- 多端发送同步：send_msg 不排除 src_channelId，全部 target channel 都收到，前端去重
- 加密握手：先发明文 ack（含密钥），再设 `encryption_enabled = True`
- 模块消息不经 `setComponentValue`，前端 callback 直接处理
- 线程安全：`loop.call_soon_threadsafe()` 非阻塞跨线程调度
- `declare_component` 懒加载：用 `_get_component_func()` 模式

## 文件

| 文件 | 说明 |
|------|------|
| `__init__.py` | PushClient + Module + register + 导出 |
| `push_core.py` | PushCore 单例 — channel→conn(1:1) + per-conn 队列 + sender task + 模块注册 |
| `user_channel_manage.py` | UserChannelManage 单例 — user→[channel_id](1:N) 业务层 |
| `routes.py` | `/st_push/ws` 路由 + `/st_push/log` 日志端点（type 驱动分发） |
| `crypto.py` | AES-256-GCM + XOR/HMAC 回退 |
| `frontend/build/index.html` | 内联协议 + WS 客户端 + 加解密 + 模块分发（v3.0 帧格式） |
| `comp/chat/` | 可选聊天组件（ChatClient + 聊天窗口 UI） |
| `comp/notify/` | 可选通知组件（NotificationClient + 铃铛+弹窗 UI） |
