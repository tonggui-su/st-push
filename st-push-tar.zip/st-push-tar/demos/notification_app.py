"""
站内消息通知 Demo（st_notify 独立组件验证）

运行方式：
    python demos/notification_app.py
"""
import sys
import os
import time

_here = os.path.dirname(os.path.abspath(__file__))
_project_root = os.path.dirname(_here)
sys.path.insert(0, _project_root)

from streamlit.web.server.starlette import App

import st_push
import st_push.comp.notify  # noqa: F401 — registers module on import

app = App(
    os.path.join(_here, "notification_script.py"),
    routes=st_push.create_push_routes(),
)

if __name__ == "__main__":
    app.run()
