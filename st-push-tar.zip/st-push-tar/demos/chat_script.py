"""
实时聊天 Streamlit 脚本（st_chat v3.0 独立组件）

由 chat_app.py 启动，WebSocket 路由已挂载到 /st_push/ws。
用不同浏览器标签打开，切换用户即可聊天。
"""
import streamlit as st

from st_push import PushClient
from st_push.comp.chat import ChatClient


# --- Session State ---

def init_state():
    if "current_user" not in st.session_state:
        st.session_state.current_user = "alice"
    if "chat_client" not in st.session_state:
        st.session_state.chat_client = None
    if "peer" not in st.session_state:
        st.session_state.peer = "bob"


init_state()


def get_chat_client() -> ChatClient:
    if st.session_state.chat_client is None:
        # 应用层创建公共 PushClient（session 单例），注入给 ChatClient
        push_client = PushClient.session_instance(user=st.session_state.current_user)
        st.session_state.chat_client = ChatClient(
            push_client=push_client,
            user_name=st.session_state.current_user,
        )
    return st.session_state.chat_client


# --- Page ---

st.set_page_config(page_title="实时聊天 - st_chat", page_icon="💬", layout="centered")
st.title("💬 实时聊天")
st.caption("st_chat v3.0 — PushClient 公共注入，session 单例，前端实时收发消息")

# User selection
users = ["alice", "bob", "carol", "dave"]
col1, col2 = st.columns([1, 1])
with col1:
    user = st.selectbox("当前用户", users, index=users.index(st.session_state.current_user))
    if user != st.session_state.current_user:
        st.session_state.current_user = user
        st.session_state.chat_client = None
        st.rerun()
with col2:
    peer = st.selectbox("聊天对象", [u for u in users if u != st.session_state.current_user], index=0)
    st.session_state.peer = peer

st.divider()

# --- Render chat window (PushClient created inside ChatClient via injection) ---
chat_client = get_chat_client()
outgoing = chat_client.render(peer=st.session_state.peer)

# Handle outgoing message from frontend
if outgoing and isinstance(outgoing, dict) and outgoing.get("action") == "send":
    content = outgoing.get("content", "")
    to_user = outgoing.get("toUser", st.session_state.peer)
    if content:
        chat_client.send(content, to_user)
        st.toast(f"已发送给 {to_user}")

st.caption("提示：在另一个浏览器标签中切换为对方用户，即可收发消息。消息通过 st_push 加密 WebSocket 实时推送。")
