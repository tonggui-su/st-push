"""
站内消息通知 Streamlit 脚本（st_notify v3.0 独立组件）

由 notification_app.py 启动，WebSocket 路由已挂载到 /st_push/ws。
用不同浏览器标签打开，切换用户即可测试跨用户通知推送。
"""
import time

import streamlit as st

from st_push import PushClient, UserChannelManage
from st_push.comp.notify import NotificationClient


# --- Session State ---

def init_state():
    if "current_user" not in st.session_state:
        st.session_state.current_user = "alice"
    if "push_client" not in st.session_state:
        st.session_state.push_client = None
    if "notification_client" not in st.session_state:
        st.session_state.notification_client = None
    if "sent_log" not in st.session_state:
        st.session_state.sent_log = []


init_state()


def get_push_client() -> PushClient:
    if st.session_state.push_client is None:
        # 应用层创建公共 PushClient（session 单例）
        st.session_state.push_client = PushClient.session_instance(
            user=st.session_state.current_user,
        )
    return st.session_state.push_client


def get_notification_client() -> NotificationClient:
    if st.session_state.notification_client is None:
        # 注入公共 PushClient 给 NotificationClient
        st.session_state.notification_client = NotificationClient(
            push_client=get_push_client(),
            user_name=st.session_state.current_user,
        )
    return st.session_state.notification_client


# --- Page ---

st.set_page_config(page_title="站内消息通知 - st_notify", page_icon="🔔", layout="wide")
st.title("🔔 站内消息通知")
st.caption("st_notify v3.0 — PushClient 公共注入，session 单例，铃铛图标 + 弹窗，点击已读")

# User selection
with st.container():
    col1, col2, col3 = st.columns([3, 2, 2])
    with col1:
        users = ["alice", "bob", "carol", "dave"]
        user = st.selectbox(
            "当前用户",
            users,
            index=users.index(st.session_state.current_user),
        )
        if user != st.session_state.current_user:
            st.session_state.current_user = user
            st.session_state.push_client = None
            st.session_state.notification_client = None
            st.rerun()
    with col2:
        st.metric("URL 用户标识", st.query_params.get("st_push_user", "—"))
    with col3:
        st.metric("通知模块 ID", get_notification_client().module_id[:8] + "...")

st.divider()

# --- Render push client (invisible transport) + notification bell ---
push_client = get_push_client()
notifier = get_notification_client()


def on_notification_click(payload):
    st.toast(f"点击了通知操作: payload={payload}")
    st.session_state.click_log.append({"payload": payload, "ts": time.time()})


if "click_log" not in st.session_state:
    st.session_state.click_log = []

clicked = notifier.render(on_click=on_notification_click)

# --- Send notification panel ---
st.subheader("发送通知")

with st.container():
    col1, col2 = st.columns([1, 1])

    with col1:
        st.markdown("**发送给指定用户**")
        with st.form("send_single"):
            target = st.selectbox("目标用户", [u for u in users if u != st.session_state.current_user])
            title = st.text_input("标题", placeholder="如：新任务分配")
            body = st.text_area("内容", placeholder="如：您被分配了「修复登录Bug」任务", height=80)
            level = st.selectbox("级别", ["info", "success", "warning", "error"])
            action_label = st.text_input("操作按钮文字（可选）", placeholder="如：查看任务")
            payload_input = st.text_input("操作 payload（可选，JSON 或文本）", placeholder="如：{\"task_id\": 123}")

            if st.form_submit_button("发送通知"):
                if title:
                    import json
                    payload_value = None
                    if payload_input:
                        try:
                            payload_value = json.loads(payload_input)
                        except json.JSONDecodeError:
                            payload_value = payload_input
                    notifier.send_notification(
                        to_user=target,
                        title=title,
                        body=body,
                        level=level,
                        action=action_label if action_label else None,
                        payload=payload_value,
                    )
                    st.session_state.sent_log.append({
                        "to": target,
                        "title": title,
                        "level": level,
                        "ts": time.time(),
                    })
                    st.success(f"已发送给 {target}")
                else:
                    st.error("请输入标题")

    with col2:
        st.markdown("**广播给所有在线用户**")
        with st.form("send_broadcast"):
            b_title = st.text_input("告警标题", placeholder="如：系统维护通知")
            b_body = st.text_area("告警内容", placeholder="如：服务器将于 10 分钟后重启", height=80)
            b_level = st.selectbox("级别", ["warning", "error", "info", "success"])

            if st.form_submit_button("广播告警"):
                if b_title:
                    notifier.broadcast_alert(
                        title=b_title,
                        body=b_body,
                        level=b_level,
                    )
                    st.session_state.sent_log.append({
                        "to": "ALL",
                        "title": b_title,
                        "level": b_level,
                        "ts": time.time(),
                    })
                    st.success("已广播")
                else:
                    st.error("请输入标题")

st.divider()

# --- Quick actions ---
st.subheader("快捷操作")
qcol1, qcol2, qcol3, qcol4 = st.columns(4)

with qcol1:
    if st.button("📨 发送任务提醒", use_container_width=True):
        target = [u for u in users if u != st.session_state.current_user][0]
        notifier.send_notification(
            to_user=target,
            title="新任务分配",
            body="您被分配了「优化首页性能」任务，截止日期：明天 18:00",
            level="info",
            action="查看任务",
            payload={"task_id": 456, "url": "/task/456"},
        )
        st.toast(f"已发送任务提醒给 {target}")

with qcol2:
    if st.button("✅ 发送审批通过", use_container_width=True):
        target = [u for u in users if u != st.session_state.current_user][0]
        notifier.send_notification(
            to_user=target,
            title="审批已通过",
            body="您的报销申请已通过审批，金额 ¥3,200",
            level="success",
        )
        st.toast(f"已发送审批通知给 {target}")

with qcol3:
    if st.button("⚠️ 发送告警", use_container_width=True):
        notifier.broadcast_alert(
            title="系统告警",
            body="数据库连接池使用率达到 85%，请关注",
            level="warning",
        )
        st.toast("已广播告警")

with qcol4:
    if st.button("🔴 紧急通知", use_container_width=True):
        notifier.broadcast_alert(
            title="紧急通知",
            body="系统将于 5 分钟后进行紧急维护，请保存工作",
            level="error",
        )
        st.toast("已广播紧急通知")

st.divider()

# --- Click log (verify on_click callback fires) ---
st.subheader("点击记录")
if st.session_state.click_log:
    for log in reversed(st.session_state.click_log[-20:]):
        st.text(f"  🖱️ payload={log['payload']}  —  {time.strftime('%H:%M:%S', time.localtime(log['ts']))}")
else:
    st.info("暂无点击记录（收到带按钮的通知后，打开铃铛 → 点击按钮）")

st.divider()

# --- Sent log ---
st.subheader("发送记录")
if st.session_state.sent_log:
    for log in reversed(st.session_state.sent_log[-20:]):
        level_emoji = {"info": "ℹ️", "success": "✅", "warning": "⚠️", "error": "🔴"}.get(log["level"], "ℹ️")
        st.text(f"{level_emoji} [{log['to']}] {log['title']}  —  {time.strftime('%H:%M:%S', time.localtime(log['ts']))}")
else:
    st.info("暂无发送记录")

# --- Online users ---
st.divider()
with st.expander("在线用户"):
    ucm = UserChannelManage.instance()
    online = ucm.get_users()
    if online:
        for u in online:
            ch_count = len(ucm.get_channels(u))
            status = "● online" if push_client.is_online(u) else "○ offline"
            st.text(f"  {status} {u} ({ch_count} channel{'s' if ch_count != 1 else ''})")
    else:
        st.info("无在线用户")

st.caption("提示：在另一个浏览器标签中切换为不同用户，然后发送带按钮的通知。点击右上角铃铛 → 点击通知按钮，下方「点击记录」会显示回调 payload。通知必须点击才能标记已读。")
