"""
实时聊天 Demo（st_chat 独立组件）

运行方式：
    python demos/chat_app.py
"""
import sys
import os

_here = os.path.dirname(os.path.abspath(__file__))
_project_root = os.path.dirname(_here)
sys.path.insert(0, _project_root)

from streamlit.web.server.starlette import App

import st_push
import st_push.comp.chat  # noqa: F401

app = App(
    os.path.join(_here, "chat_script.py"),
    routes=st_push.create_push_routes(),
)

if __name__ == "__main__":
    app.run()
